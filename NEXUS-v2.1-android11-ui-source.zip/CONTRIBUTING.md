# Contributing

1. Fork and create a feature branch (`feat/my-feature`).
2. Keep the security posture: **no arbitrary shell execution**, no unauthenticated endpoints.
3. Run the tests: `python -m pytest desktop/tests -q`.
4. Match the code style: type hints, small routers, pydantic schemas for requests.
5. Update `docs/protocol.md` and `CHANGELOG.md` for API changes.
6. Open a pull request with a clear description.

## Project layout

```text
desktop/app/          FastAPI core + PySide6 console
  core/               auth, security, websocket
  routers/            one file per feature area
  services/           metrics, files, discovery, input, media
android/              Kotlin/Compose client
docs/                 protocol & guides
```

## Release checklist

- [ ] Tests green
- [ ] `CHANGELOG.md` updated
- [ ] Version bumped in `config.py`, `build.gradle.kts`, `README.md`
- [ ] APK built (`./gradlew assembleRelease`) and attached to the GitHub release
