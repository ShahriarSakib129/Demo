# Changelog

## [2.0.1] — 2026-10-17

### Fixed
- `ImportError: cannot import name 'admin_token_path'` — the function now lives in
  `config.py` (`core/security.py` re-exports it); `python -m desktop.app.main` works again
- **v1→v2 database auto-migration**: legacy 6-column `devices` tables are upgraded
  (`battery_level`, `battery_status`, `last_battery_update` added) on startup —
  fixes `sqlite3.OperationalError: table devices has 6 columns but 9 values were supplied`
- `INSERT` statements now use explicit column names (robust against future schema changes)

### Added
- Regression tests: CLI module import smoke test + legacy database migration test

## [2.0.0] — 2026-10-17

### Added
- **Realtime WebSocket channel** (`/ws`) with device/admin token auth and polling fallback
- **QR pairing**: desktop QR display + Android QR scanner (ZXing embedded)
- **Find my phone**: ring + vibrate from the desktop, silencing supported
- **Remote input**: keyboard typing, hotkeys (ctrl/alt/super combos), virtual touchpad
- **Media & volume control**: playerctl integration, pactl/amixer volume
- **SMS relay**: queue SMS from the PC, phone sends via SmsManager
- **Phone battery/status** reporting and desktop device table
- **Share-to-PC** via Android share sheet (text → clipboard, files → upload)
- **Photo backup** from Android MediaStore into `phone-backup/`
- **Resumable chunked upload** API (`/files/chunk`) for large files
- **Clipboard history** (last 20 entries) with bounded retention
- **Metrics history** (48h) with desktop charts (CPU/memory)
- **Automation catalog**: organize-by-extension + partial-upload cleanup
- **Device rename** endpoint and management UI
- Android **background bridge service** (opt-in foreground service)
- Desktop console v2: tabs (Dashboard/Pairing/Devices/Files/Logs), drag & drop

### Security
- Pairing endpoints now require `X-Admin-Token` (auto-generated, 0600 file)
- Rate limiting preserved (240 req/min per IP), public paths allowlisted
- Files API: strict name/folder validation (regex + resolve checks)
- Key input allowlist pattern rejects shell metacharacters
- Token comparison uses constant-time `hmac.compare_digest`

### Changed
- Codebase restructured: `routers/`, `core/`, `services/`, `schemas.py`
- FastAPI `lifespan` replaces deprecated `on_event` handlers
- SQLite uses WAL mode + busy timeout + an RLock
- Download endpoint is now `GET /files/download?name=&folder=`
- Android client architecture: `data/Api`, `data/Session`, `services/`, `ui/`

## [1.0.0] — 2026-10-17

### Added
- FastAPI NEXUS Core, pairing codes, bearer auth, metrics, file exchange
- PySide6 desktop GUI, Android Kotlin/Compose client, notification mirroring
- LAN discovery (Zeroconf), clipboard controls, power actions, file organizer
