package com.nexus.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import com.nexus.app.data.Api
import com.nexus.app.data.Session
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * "Share to PC" entry point: Android share-sheet target that uploads
 * text or files straight into the NEXUS shared folder.
 */
class ShareReceiverActivity : Activity() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val api = Api()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Session.init(this)
        if (!Session.paired()) {
            Toast.makeText(this, "Pair NEXUS with your PC first", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        handleShare(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleShare(intent)
    }

    private fun handleShare(intent: Intent?) {
        val type = intent?.type ?: "text/plain"
        if (intent?.action == Intent.ACTION_SEND) {
            if (type.startsWith("text/")) {
                val text = intent.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
                if (text.isNotBlank()) {
                    scope.launch {
                        val result = api.setClipboard(text)
                        val message = result.fold(
                            { "Sent to PC" },
                            { "Send failed: ${it.message}" }
                        )
                        runOnUiThread {
                            Toast.makeText(
                                this@ShareReceiverActivity,
                                message,
                                Toast.LENGTH_SHORT
                            ).show()
                            finish()
                        }
                    }
                    return
                }
            }
            @Suppress("DEPRECATION")
            val uri: android.net.Uri? = intent.getParcelableExtra(Intent.EXTRA_STREAM)
            if (uri != null) {
                val name = Api.displayName(this, uri)
                scope.launch {
                    val result = api.upload(this@ShareReceiverActivity, uri, name)
                    runOnUiThread {
                        Toast.makeText(
                            this@ShareReceiverActivity,
                            result.getOrElse { "Upload failed: ${it.message}" },
                            Toast.LENGTH_LONG
                        ).show()
                        finish()
                    }
                }
                return
            }
        }
        finish()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
