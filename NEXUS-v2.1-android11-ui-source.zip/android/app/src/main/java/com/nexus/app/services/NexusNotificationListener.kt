package com.nexus.app.services

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.nexus.app.data.Api
import com.nexus.app.data.Session
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Opt-in notification mirroring. Disabled by default; toggled from the app.
 * Also exposes helpers used by remote "dismiss" commands.
 */
class NexusNotificationListener : NotificationListenerService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val api = Api()

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!Session.notificationsEnabled) return
        if (!Session.paired()) return
        if (sbn.packageName == packageName) return

        val title = sbn.notification.extras.getCharSequence("android.title")?.toString().orEmpty()
        val text = sbn.notification.extras.getCharSequence("android.text")?.toString().orEmpty()
        scope.launch {
            runCatching { api.pushNotification(sbn.packageName, title, text) }
        }
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        scope.cancel()
    }

    companion object {
        fun cancelByKey(service: NotificationListenerService?, key: String) {
            runCatching { service?.cancelNotification(key) }
        }
    }
}
