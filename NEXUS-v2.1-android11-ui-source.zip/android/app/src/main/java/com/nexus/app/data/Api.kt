package com.nexus.app.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

data class RemoteFile(val name: String, val folder: String, val size: Long)
data class RemoteNotification(val id: Int, val source: String, val title: String, val text: String)
data class PhoneCommand(val id: Int, val type: String, val payload: String)

/** Blocking REST client for the NEXUS Core API. Call from Dispatchers.IO. */
class Api {
    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    private fun url(path: String) = Session.base.trimEnd('/') + path

    private fun authed(path: String): Request.Builder? {
        val token = Session.token ?: return null
        return Request.Builder().url(url(path)).header("Authorization", "Bearer $token")
    }

    private inline fun <T> execute(builder: Request.Builder?, block: (String) -> T): T {
        val request = builder?.build() ?: error("Not paired yet")
        client.newCall(request).execute().use { response ->
            val body = response.body?.string().orEmpty()
            if (!response.isSuccessful) error("HTTP ${response.code}: ${body.take(120)}")
            return block(body)
        }
    }

    // ------------------------------------------------------------- pairing --
    fun discoverPing(): Result<String> = runCatching {
        execute(Request.Builder().url(url("/health")).get()) { "NEXUS Core found" }
    }

    fun pair(code: String, name: String): Result<String> = runCatching {
        val body = JSONObject(mapOf("code" to code, "device_name" to name))
            .toString().toRequestBody("application/json".toMediaType())
        execute(Request.Builder().url(url("/pair")).post(body)) { raw ->
            val token = JSONObject(raw).getString("token")
            Session.token = token
            Session.deviceName = name
            "Paired successfully"
        }
    }

    fun reportBattery(level: Int?, status: String?): Result<Unit> = runCatching {
        val body = JSONObject().apply {
            level?.let { put("level", it) }
            status?.let { put("status", it) }
        }.toString().toRequestBody("application/json".toMediaType())
        execute(authed("/device/status")?.post(body)) { }
    }

    // ------------------------------------------------------------ dashboard --
    fun metrics(): Result<String> = runCatching {
        execute(authed("/metrics")?.get()) { raw ->
            val j = JSONObject(raw)
            "CPU ${j.getDouble("cpu_percent")}%  •  RAM ${j.getDouble("memory_percent")}%\n" +
                "Disk ${j.getDouble("disk_percent")}%  •  Up ${j.getLong("uptime_seconds") / 60} min\n" +
                "Net ↑${j.getLong("network_bytes_sent") / 1024} KiB ↓${j.getLong("network_bytes_recv") / 1024} KiB"
        }
    }

    fun devicesInfo(): Result<String> = runCatching {
        execute(authed("/devices")?.get()) { raw ->
            val items = JSONObject(raw).getJSONArray("items")
            buildString {
                for (i in 0 until items.length()) {
                    val d = items.getJSONObject(i)
                    val battery = if (d.has("battery_level") && !d.isNull("battery_level"))
                        "${d.getInt("battery_level")}%" else "—"
                    append("• ${d.getString("name")} — battery $battery\n")
                }
            }
        }
    }

    // ---------------------------------------------------------------- files --
    fun listFiles(): Result<List<RemoteFile>> = runCatching {
        execute(authed("/files")?.get()) { raw ->
            val items = JSONObject(raw).getJSONArray("items")
            (0 until items.length()).map {
                val o = items.getJSONObject(it)
                RemoteFile(o.getString("name"), o.optString("folder", ""), o.getLong("size"))
            }
        }
    }

    fun upload(context: Context, uri: Uri, displayName: String, folder: String = "phone-uploads"): Result<String> =
        runCatching {
            val cache = File(context.cacheDir, "upload_${System.currentTimeMillis()}")
            context.contentResolver.openInputStream(uri)?.use { input ->
                cache.outputStream().use { output -> input.copyTo(output) }
            } ?: error("Cannot read file")
            val part = MultipartBody.Part.createFormData(
                "file", displayName, cache.asRequestBody("application/octet-stream".toMediaType())
            )
            val builder = MultipartBody.Builder().setType(MultipartBody.FORM)
                .addFormDataPart("folder", folder)
                .addPart(part)
            try {
                execute(authed("/files/upload")?.post(builder.build())) { "Uploaded $displayName" }
            } finally {
                cache.delete()
            }
        }

    fun download(name: String, folder: String, dest: File): Result<File> = runCatching {
        val path = "/files/download?name=${Uri.encode(name)}" +
            if (folder.isNotEmpty()) "&folder=${Uri.encode(folder)}" else ""
        val request = authed(path)?.get()?.build() ?: error("Not paired yet")
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Download failed (${response.code})")
            response.body?.byteStream()?.use { input ->
                dest.outputStream().use { output -> input.copyTo(output) }
            }
            dest
        }
    }

    fun deleteFile(name: String, folder: String): Result<Unit> = runCatching {
        val path = "/files?name=${Uri.encode(name)}" +
            if (folder.isNotEmpty()) "&folder=${Uri.encode(folder)}" else ""
        execute(authed(path)?.delete()) { }
    }

    // ------------------------------------------------------------ clipboard --
    fun getClipboard(): Result<String> = runCatching {
        execute(authed("/clipboard")?.get()) { JSONObject(it).optString("text", "") }
    }

    fun setClipboard(text: String): Result<Unit> = runCatching {
        val body = JSONObject(mapOf("text" to text)).toString()
            .toRequestBody("application/json".toMediaType())
        execute(authed("/clipboard")?.post(body)) { }
    }

    // -------------------------------------------------------- notifications --
    fun notifications(): Result<List<RemoteNotification>> = runCatching {
        execute(authed("/notifications")?.get()) { raw ->
            val items = JSONObject(raw).getJSONArray("items")
            (0 until items.length()).map {
                val o = items.getJSONObject(it)
                RemoteNotification(o.getInt("id"), o.getString("source"), o.getString("title"), o.optString("text"))
            }
        }
    }

    fun dismissNotification(id: Int, action: String = "dismiss"): Result<Unit> = runCatching {
        val body = JSONObject(mapOf("action" to action)).toString()
            .toRequestBody("application/json".toMediaType())
        execute(authed("/notifications/$id/dismiss")?.post(body)) { }
    }

    fun pushNotification(source: String, title: String, text: String): Result<Unit> = runCatching {
        val body = JSONObject(mapOf("source" to source, "title" to title, "text" to text))
            .toString().toRequestBody("application/json".toMediaType())
        execute(authed("/notifications")?.post(body)) { }
    }

    // ------------------------------------------------------- phone commands --
    fun findPhone(): Result<Unit> = runCatching {
        val body = "{\"duration_seconds\": 30}".toRequestBody("application/json".toMediaType())
        execute(authed("/phone/find")?.post(body)) { }
    }

    fun stopFind(): Result<Unit> = runCatching {
        val body = "{}".toRequestBody("application/json".toMediaType())
        execute(authed("/phone/find/stop")?.post(body)) { }
    }

    fun sendSms(to: String, text: String): Result<Unit> = runCatching {
        val body = JSONObject(mapOf("to" to to, "text" to text)).toString()
            .toRequestBody("application/json".toMediaType())
        execute(authed("/sms/send")?.post(body)) { }
    }

    fun pollCommands(): Result<List<PhoneCommand>> = runCatching {
        execute(authed("/phone/commands")?.get()) { raw ->
            val items = JSONObject(raw).getJSONArray("items")
            (0 until items.length()).map {
                val o = items.getJSONObject(it)
                PhoneCommand(o.getInt("id"), o.getString("type"), o.optString("payload", ""))
            }
        }
    }

    fun ackCommand(id: Int): Result<Unit> = runCatching {
        execute(authed("/phone/commands/$id/ack")?.post(ByteArray(0).toRequestBody())) { }
    }

    // ------------------------------------------------------------ pc control --
    fun power(action: String): Result<Unit> = runCatching {
        val body = "{\"confirm\": true}".toRequestBody("application/json".toMediaType())
        execute(authed("/power/$action")?.post(body)) { }
    }

    fun organize(): Result<Unit> = runCatching {
        val body = "{\"action\": \"organize_shared\", \"confirm\": true}"
            .toRequestBody("application/json".toMediaType())
        execute(authed("/automations/run")?.post(body)) { }
    }

    fun media(action: String): Result<Unit> = runCatching {
        execute(authed("/media/$action")?.post(ByteArray(0).toRequestBody())) { }
    }

    fun volume(level: Int): Result<Unit> = runCatching {
        val body = JSONObject(mapOf("level" to level)).toString()
            .toRequestBody("application/json".toMediaType())
        execute(authed("/media/volume/set")?.post(body)) { }
    }

    fun key(key: String): Result<Unit> = runCatching {
        val body = JSONObject(mapOf("key" to key)).toString()
            .toRequestBody("application/json".toMediaType())
        execute(authed("/input/key")?.post(body)) { }
    }

    fun typeText(text: String): Result<Unit> = runCatching {
        val body = JSONObject(mapOf("text" to text)).toString()
            .toRequestBody("application/json".toMediaType())
        execute(authed("/input/type")?.post(body)) { }
    }

    fun mouse(action: String, dx: Int = 0, dy: Int = 0): Result<Unit> = runCatching {
        val body = JSONObject(mapOf("action" to action, "dx" to dx, "dy" to dy)).toString()
            .toRequestBody("application/json".toMediaType())
        execute(authed("/input/mouse")?.post(body)) { }
    }

    fun mediaStatus(): Result<String> = runCatching {
        execute(authed("/media/status")?.get()) { raw ->
            val j = JSONObject(raw)
            if (!j.optBoolean("available", false)) j.optString("message", "Unavailable")
            else "${j.optString("state", "?")} — ${j.optString("title", "")} / ${j.optString("artist", "")}"
        }
    }

    companion object {
        fun displayName(context: Context, uri: Uri): String {
            var name = "android-file"
            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (index >= 0) name = cursor.getString(index) ?: name
                }
            }
            return name
        }
    }
}
