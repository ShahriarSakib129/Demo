package com.nexus.app.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys

/**
 * Encrypted session storage: pairing token + base URL are stored in
 * Android Keystore-backed preferences; UI preferences are kept separately.
 */
object Session {
    private lateinit var secure: SharedPreferences
    private lateinit var local: SharedPreferences

    fun init(context: Context) {
        if (::secure.isInitialized) return
        val masterKey = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)
        secure = EncryptedSharedPreferences.create(
            "nexus_secure",
            masterKey,
            context,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
        local = context.getSharedPreferences("nexus_local", Context.MODE_PRIVATE)
    }

    var base: String
        get() = secure.getString("base", "") ?: ""
        set(value) {
            secure.edit().putString("base", value.trim().trimEnd('/')).apply()
        }

    var token: String?
        get() = secure.getString("token", null)
        set(value) {
            secure.edit().putString("token", value).apply()
        }

    var deviceName: String
        get() = local.getString("name", "My Android") ?: "My Android"
        set(value) {
            local.edit().putString("name", value).apply()
        }

    var notificationsEnabled: Boolean
        get() = local.getBoolean("enabled", false)
        set(value) {
            local.edit().putBoolean("enabled", value).apply()
        }

    var backgroundSync: Boolean
        get() = local.getBoolean("background", false)
        set(value) {
            local.edit().putBoolean("background", value).apply()
        }

    fun paired(): Boolean = token != null && base.isNotEmpty()

    fun clearToken() {
        secure.edit().remove("token").apply()
    }
}
