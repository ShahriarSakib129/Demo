package com.nexus.app.ui

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import com.nexus.app.data.Api
import com.nexus.app.data.RemoteFile
import com.nexus.app.data.RemoteNotification
import com.nexus.app.data.Session
import com.nexus.app.services.PhoneService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

private enum class Tab(val label: String) {
    CONNECT("Connect"), DASHBOARD("Dashboard"), FILES("Files"),
    CONTROL("Control"), ALERTS("Alerts")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NexusApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val api = remember { Api() }
    var tab by remember { mutableStateOf(Tab.CONNECT) }
    var status by remember { mutableStateOf(if (Session.paired()) "Paired" else "Not connected") }

    fun exec(block: suspend () -> String) {
        scope.launch {
            status = "Working…"
            status = try {
                withContext(Dispatchers.IO) { block() }
            } catch (e: Exception) {
                "Error: ${e.message}"
            }
        }
    }

    val nexusColors = darkColorScheme(
        primary = androidx.compose.ui.graphics.Color(0xFF9B7BFF),
        onPrimary = androidx.compose.ui.graphics.Color(0xFF140B2E),
        primaryContainer = androidx.compose.ui.graphics.Color(0xFF34205F),
        onPrimaryContainer = androidx.compose.ui.graphics.Color(0xFFE9DDFF),
        secondary = androidx.compose.ui.graphics.Color(0xFFC4B5FD),
        background = androidx.compose.ui.graphics.Color(0xFF09090F),
        onBackground = androidx.compose.ui.graphics.Color(0xFFF4F1FF),
        surface = androidx.compose.ui.graphics.Color(0xFF11111B),
        onSurface = androidx.compose.ui.graphics.Color(0xFFF4F1FF),
        surfaceVariant = androidx.compose.ui.graphics.Color(0xFF20202D),
        onSurfaceVariant = androidx.compose.ui.graphics.Color(0xFFB9B5CC),
        outline = androidx.compose.ui.graphics.Color(0xFF494458),
        error = androidx.compose.ui.graphics.Color(0xFFFF6B81)
    )
    MaterialTheme(colorScheme = nexusColors) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("NEXUS", fontWeight = FontWeight.Bold) },
                    actions = {
                        Text(
                            if (Session.paired()) "●" else "○",
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(Modifier.width(12.dp))
                    }
                )
            },
            bottomBar = {
                NavigationBar {
                    Tab.entries.forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            label = { Text(item.label) },
                            icon = {
                                val iconName = when (item) {
                                    Tab.CONNECT -> "↔"
                                    Tab.DASHBOARD -> "▦"
                                    Tab.FILES -> "▤"
                                    Tab.CONTROL -> "⌘"
                                    Tab.ALERTS -> "♧"
                                }
                                Text(iconName, fontWeight = FontWeight.Bold)
                            }
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.padding(padding).padding(horizontal = 12.dp)) {
                Text(status, style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 6.dp))
                when (tab) {
                    Tab.CONNECT -> ConnectScreen(api, ::exec) { status = it }
                    Tab.DASHBOARD -> DashboardScreen(api, ::exec)
                    Tab.FILES -> FilesScreen(api, ::exec)
                    Tab.CONTROL -> ControlScreen(api, ::exec)
                    Tab.ALERTS -> AlertsScreen(api, ::exec)
                }
            }
        }
    }
}


// ---------------------------------------------------------------- CONNECT --
@Composable
private fun ConnectScreen(api: Api, exec: (suspend () -> String) -> Unit, setStatus: (String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var base by remember { mutableStateOf(Session.base.ifEmpty { "http://192.168.1.10:8765" }) }
    var name by remember { mutableStateOf(Session.deviceName) }
    var code by remember { mutableStateOf("") }
    var notificationsOn by remember { mutableStateOf(Session.notificationsEnabled) }
    var backgroundOn by remember { mutableStateOf(Session.backgroundSync) }

    val scanLauncher = rememberLauncherForActivityResult(ScanContract()) { result ->
        val contents = result.contents ?: return@rememberLauncherForActivityResult
        parsePairingPayload(contents)?.let { (host, pairingCode) ->
            base = host
            code = pairingCode
            Session.base = host
            setStatus("QR scanned — press Pair")
        } ?: setStatus("Unrecognised QR code")
    }

    val notifPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        Session.notificationsEnabled = granted
        notificationsOn = granted
        setStatus(if (granted) "Notification mirroring enabled" else "Permission denied")
    }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.verticalScroll(rememberScrollState())) {
        OutlinedTextField(base, { base = it; Session.base = it },
            label = { Text("Linux Core URL / Tailscale IP") },
            modifier = Modifier.fillMaxWidth())
        OutlinedTextField(name, { name = it; Session.deviceName = it },
            label = { Text("Device name") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(code, { code = it.filter(Char::isDigit).take(6) },
            label = { Text("6-digit pairing code") }, modifier = Modifier.fillMaxWidth())

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = {
                exec {
                    api.pair(code, name).getOrElse { error(it) }
                }
            }) { Text("Pair") }
            OutlinedButton(onClick = {
                exec { api.discoverPing().getOrElse { error(it) } }
            }) { Text("Ping Core") }
            OutlinedButton(onClick = {
                scanLauncher.launch(
                    ScanOptions().setDesiredBarcodeFormats(ScanOptions.QR_CODE)
                        .setPrompt("Scan the pairing QR on the desktop")
                        .setBeepEnabled(false)
                )
            }) { Text("Scan QR") }
        }

        OutlinedButton(onClick = {
            discoverLan { discovered ->
                if (discovered.isNotEmpty()) {
                    base = discovered
                    Session.base = discovered
                    setStatus("Discovered $discovered")
                } else setStatus("No Core found — enter the URL manually")
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("Discover LAN") }

        HorizontalDivider()
        Text("Permissions & background", style = MaterialTheme.typography.titleMedium)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = notificationsOn, onCheckedChange = { enabled ->
                if (enabled && Build.VERSION.SDK_INT >= 33 &&
                    ContextCompat.checkSelfPermission(
                        context, Manifest.permission.POST_NOTIFICATIONS
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                } else if (enabled) {
                    val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                    context.startActivity(intent)
                    Session.notificationsEnabled = true
                    notificationsOn = true
                } else {
                    Session.notificationsEnabled = false
                    notificationsOn = false
                }
            })
            Spacer(Modifier.width(8.dp))
            Text("Mirror notifications to PC")
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = backgroundOn, onCheckedChange = { enabled ->
                backgroundOn = enabled
                Session.backgroundSync = enabled
                if (enabled) PhoneService.start(context) else PhoneService.stop(context)
                setStatus(if (enabled) "Background bridge started" else "Background bridge stopped")
            })
            Spacer(Modifier.width(8.dp))
            Text("Background bridge (find-my-phone)")
        }
        TextButton(onClick = {
            context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }) { Text("Open notification access settings") }
    }
}

private fun parsePairingPayload(payload: String): Pair<String, String>? {
    // Formats: "nexus://pair?host=URL&code=123456" | "URL|CODE" | bare "URL CODE"
    val text = payload.trim()
    if (text.startsWith("nexus://")) {
        val host = Regex("host=([^&]+)").find(text)?.groupValues?.get(1)?.let { Uri.decode(it) }
        val code = Regex("code=(\\d{6})").find(text)?.groupValues?.get(1)
        return if (host != null && code != null) host to code else null
    }
    val parts = text.split(Regex("[|\\s]+")).filter { it.isNotBlank() }
    return if (parts.size >= 2 && parts[1].matches(Regex("\\d{6}"))) parts[0] to parts[1] else null
}

private fun discoverLan(callback: (String) -> Unit) {
    val manager = NexusAppContext.get()?.getSystemService(NsdManager::class.java)
    if (manager == null) {
        callback("")
        return
    }
    var done = false
    lateinit var listener: NsdManager.DiscoveryListener
    fun finish(value: String) {
        if (!done) {
            done = true
            runCatching { manager.stopServiceDiscovery(listener) }
            callback(value)
        }
    }
    listener = object : NsdManager.DiscoveryListener {
        override fun onDiscoveryStarted(serviceType: String) {}
        override fun onServiceFound(service: NsdServiceInfo) {
            if (service.serviceType.contains("_nexus")) {
                manager.resolveService(service, object : NsdManager.ResolveListener {
                    override fun onResolveFailed(service: NsdServiceInfo, errorCode: Int) {}
                    override fun onServiceResolved(service: NsdServiceInfo) {
                        finish("http://${service.host?.hostAddress}:${service.port}")
                    }
                })
            }
        }
        override fun onServiceLost(service: NsdServiceInfo) {}
        override fun onDiscoveryStopped(serviceType: String) {}
        override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) { finish("") }
        override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) { done = true }
    }
    manager.discoverServices("_nexus._tcp", NsdManager.PROTOCOL_DNS_SD, listener)
    Handler(Looper.getMainLooper()).postDelayed({ finish("") }, 5000)
}

// --------------------------------------------------------------- DASHBOARD --
@Composable
private fun DashboardScreen(api: Api, exec: (suspend () -> String) -> Unit) {
    var metrics by remember { mutableStateOf("Press refresh to load metrics") }
    var devices by remember { mutableStateOf("") }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Button(onClick = {
            exec {
                metrics = api.metrics().getOrElse { error(it) }
                devices = api.devicesInfo().getOrDefault("")
                "Metrics updated"
            }
        }) { Text("Refresh metrics") }
        Card(Modifier.fillMaxWidth()) {
            Text(metrics, Modifier.padding(14.dp), fontFamily = FontFamily.Monospace)
        }
        if (devices.isNotEmpty()) {
            Text("Paired devices", style = MaterialTheme.typography.titleMedium)
            Card(Modifier.fillMaxWidth()) { Text(devices, Modifier.padding(14.dp)) }
        }
    }
}

// ------------------------------------------------------------------- FILES --
@Composable
private fun FilesScreen(api: Api, exec: (suspend () -> String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var files by remember { mutableStateOf(emptyList<RemoteFile>()) }

    fun refresh() {
        scope.launch {
            files = withContext(Dispatchers.IO) {
                api.listFiles().getOrDefault(emptyList())
            }
        }
    }
    LaunchedEffect(Unit) { refresh() }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            exec {
                val name = Api.displayName(context, uri)
                val message = api.upload(context, uri, name).getOrElse { error(it) }
                refresh()
                message
            }
        }
    }

    val photoPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            exec {
                val count = backupPhotos(context, api)
                refresh()
                "Backed up $count photo(s)"
            }
        }
    }

    Column {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { picker.launch("*/*") }) { Text("Upload") }
            OutlinedButton(onClick = { refresh() }) { Text("Refresh") }
            OutlinedButton(onClick = {
                val permission = if (Build.VERSION.SDK_INT >= 33)
                    Manifest.permission.READ_MEDIA_IMAGES
                else Manifest.permission.READ_EXTERNAL_STORAGE
                if (ContextCompat.checkSelfPermission(context, permission) ==
                    PackageManager.PERMISSION_GRANTED
                ) {
                    exec {
                        val count = backupPhotos(context, api)
                        refresh()
                        "Backed up $count photo(s)"
                    }
                } else photoPermission.launch(permission)
            }) { Text("Backup photos") }
        }
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(files) { file ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(file.name, fontWeight = FontWeight.Medium)
                            Text(
                                "${if (file.folder.isNotEmpty()) file.folder + " • " else ""}${file.size} bytes",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        TextButton(onClick = {
                            exec {
                                val dest = java.io.File(context.getExternalFilesDir(null), file.name)
                                api.download(file.name, file.folder, dest).getOrElse { error(it) }
                                "Saved to ${dest.name}"
                            }
                        }) { Text("Get") }
                        TextButton(onClick = {
                            exec {
                                api.deleteFile(file.name, file.folder).getOrElse { error(it) }
                                refresh()
                                "Deleted ${file.name}"
                            }
                        }) { Text("Del") }
                    }
                }
            }
        }
    }
}

private suspend fun backupPhotos(context: android.content.Context, api: Api): Int {
    return withContext(Dispatchers.IO) {
        var count = 0
        val projection = arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME)
        val cursor = context.contentResolver.query(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
            projection, null, null,
            "${MediaStore.Images.Media.DATE_ADDED} DESC"
        )
        cursor?.use {
            val idIndex = it.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
            val nameIndex = it.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
            var scanned = 0
            while (it.moveToNext() && scanned < 10) {
                val id = it.getLong(idIndex)
                val name = it.getString(nameIndex) ?: "photo.jpg"
                val uri = Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "$id")
                if (api.upload(context, uri, name, "phone-backup").isSuccess) count++
                scanned++
            }
        }
        count
    }
}

// ----------------------------------------------------------------- CONTROL --
@Composable
private fun ControlScreen(api: Api, exec: (suspend () -> String) -> Unit) {
    val scope = rememberCoroutineScope()
    var confirmAction by remember { mutableStateOf<String?>(null) }
    var mediaInfo by remember { mutableStateOf("Media: unknown") }
    var volume by remember { mutableStateOf(50f) }
    var typeText by remember { mutableStateOf("") }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.verticalScroll(rememberScrollState())) {

        Text("Safe PC controls", style = MaterialTheme.typography.titleMedium)
        Text("No arbitrary terminal execution is provided.",
            style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button(onClick = { confirmAction = "lock" }) { Text("Lock") }
            OutlinedButton(onClick = { confirmAction = "suspend" }) { Text("Suspend") }
            OutlinedButton(onClick = { confirmAction = "restart" }) { Text("Restart") }
            OutlinedButton(onClick = { confirmAction = "shutdown" }) { Text("Shut down") }
        }

        HorizontalDivider()
        Text("Media", style = MaterialTheme.typography.titleMedium)
        Text(mediaInfo, style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedButton(onClick = { exec { api.media("previous").getOrElse { error(it) }; "Previous" } }) { Text("⏮") }
            Button(onClick = { exec { api.media("play-pause").getOrElse { error(it) }; "Play/Pause" } }) { Text("⏯") }
            OutlinedButton(onClick = { exec { api.media("next").getOrElse { error(it) }; "Next" } }) { Text("⏭") }
            TextButton(onClick = {
                scope.launch {
                    mediaInfo = withContext(Dispatchers.IO) {
                        api.mediaStatus().getOrDefault("Media: unknown")
                    }
                }
            }) { Text("Status") }
        }
        Text("Volume: ${volume.roundToInt()}%")
        Slider(
            value = volume,
            onValueChange = { volume = it },
            onValueChangeFinished = {
                exec {
                    api.volume(volume.roundToInt()).getOrElse { error(it) }
                    "Volume set to ${volume.roundToInt()}%"
                }
            },
            valueRange = 0f..100f
        )

        HorizontalDivider()
        Text("Remote keyboard & mouse", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedButton(onClick = { exec { api.key("Return").getOrElse { error(it) }; "Enter" } }) { Text("Enter") }
            OutlinedButton(onClick = { exec { api.key("BackSpace").getOrElse { error(it) }; "Backspace" } }) { Text("⌫") }
            OutlinedButton(onClick = { exec { api.key("Escape").getOrElse { error(it) }; "Esc" } }) { Text("Esc") }
            OutlinedButton(onClick = { exec { api.key("super").getOrElse { error(it) }; "Super" } }) { Text("Super") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedButton(onClick = { exec { api.key("ctrl+c").getOrElse { error(it) }; "Ctrl+C" } }) { Text("Ctrl+C") }
            OutlinedButton(onClick = { exec { api.key("ctrl+v").getOrElse { error(it) }; "Ctrl+V" } }) { Text("Ctrl+V") }
            OutlinedButton(onClick = { exec { api.key("alt+Tab").getOrElse { error(it) }; "Alt+Tab" } }) { Text("Alt+Tab") }
        }
        OutlinedTextField(typeText, { typeText = it },
            label = { Text("Type on the PC") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = {
            exec {
                api.typeText(typeText).getOrElse { error(it) }
                "Typed ${typeText.length} chars"
            }
        }) { Text("Send text") }

        // Touchpad surface
        var dragX by remember { mutableStateOf(0f) }
        var dragY by remember { mutableStateOf(0f) }
        Card(Modifier.fillMaxWidth().height(160.dp).pointerInput(Unit) {
            detectTapGestures(
                onTap = {
                    scope.launch { withContext(Dispatchers.IO) { api.mouse("click") } }
                },
                onDoubleTap = {
                    scope.launch { withContext(Dispatchers.IO) { api.mouse("double") } }
                },
                onLongPress = {
                    scope.launch { withContext(Dispatchers.IO) { api.mouse("right") } }
                }
            )
        }.pointerInput(Unit) {
            detectDragGestures { change, drag ->
                change.consume()
                dragX += drag.x
                dragY += drag.y
                if (kotlin.math.abs(dragX) > 8 || kotlin.math.abs(dragY) > 8) {
                    val dx = dragX.roundToInt()
                    val dy = dragY.roundToInt()
                    dragX = 0f; dragY = 0f
                    scope.launch { withContext(Dispatchers.IO) { api.mouse("move", dx, dy) } }
                }
            }
        }) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Touchpad — tap: click • double: double-click • hold: right-click")
            }
        }
    }

    confirmAction?.let { action ->
        AlertDialog(
            onDismissRequest = { confirmAction = null },
            title = { Text("Confirm $action") },
            text = { Text("This will $action the Linux PC. Continue?") },
            confirmButton = {
                TextButton(onClick = {
                    confirmAction = null
                    exec {
                        api.power(action).getOrElse { error(it) }
                        "$action requested"
                    }
                }) { Text("Confirm") }
            },
            dismissButton = {
                TextButton(onClick = { confirmAction = null }) { Text("Cancel") }
            }
        )
    }
}

// ------------------------------------------------------------------ ALERTS --
@Composable
private fun AlertsScreen(api: Api, exec: (suspend () -> String) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var notices by remember { mutableStateOf(emptyList<RemoteNotification>()) }
    var clip by remember { mutableStateOf("") }
    var clipInput by remember { mutableStateOf("") }
    var smsTo by remember { mutableStateOf("") }
    var smsText by remember { mutableStateOf("") }

    fun refresh() {
        scope.launch {
            notices = withContext(Dispatchers.IO) {
                api.notifications().getOrDefault(emptyList())
            }
        }
    }
    LaunchedEffect(Unit) { refresh() }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        item {
            Button(onClick = {
                exec {
                    api.findPhone().getOrElse { error(it) }
                    "Find-my-phone triggered — your phone should ring"
                }
            }) { Text("🔔 Find my phone") }
        }
        item {
            OutlinedButton(onClick = {
                exec { api.stopFind().getOrElse { error(it) }; "Silenced" }
            }) { Text("Stop ringing") }
        }
        item {
            HorizontalDivider()
            Text("SMS via PC", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(smsTo, { smsTo = it },
                label = { Text("Phone number") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(smsText, { smsText = it },
                label = { Text("Message") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = {
                exec {
                    api.sendSms(smsTo, smsText).getOrElse { error(it) }
                    "SMS queued"
                }
            }) { Text("Send SMS") }
        }
        item {
            HorizontalDivider()
            Text("Clipboard", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(clipInput, { clipInput = it },
                label = { Text("Text to send to Linux") }, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    exec { api.setClipboard(clipInput).getOrElse { error(it) }; "Clipboard updated" }
                }) { Text("Send") }
                OutlinedButton(onClick = {
                    scope.launch {
                        clip = withContext(Dispatchers.IO) {
                            api.getClipboard().getOrDefault("")
                        }
                    }
                }) { Text("Read PC clipboard") }
            }
            if (clip.isNotEmpty()) Text("PC: $clip")
        }
        item {
            HorizontalDivider()
            Row {
                Text("Notifications", style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.weight(1f))
                TextButton(onClick = { refresh() }) { Text("Refresh") }
            }
        }
        items(notices) { notice ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(10.dp)) {
                    Text(notice.title, style = MaterialTheme.typography.titleSmall)
                    Text("${notice.source}: ${notice.text}")
                    Row {
                        TextButton(onClick = {
                            exec {
                                api.dismissNotification(notice.id, "dismiss").getOrElse { error(it) }
                                refresh()
                                "Dismissed on phone"
                            }
                        }) { Text("Dismiss on phone") }
                        TextButton(onClick = {
                            exec {
                                api.dismissNotification(notice.id, "open").getOrElse { error(it) }
                                "Opened on phone"
                            }
                        }) { Text("Open on phone") }
                    }
                }
            }
        }
    }
}

/** Tiny static holder so NSD discovery can reach a Context. */
object NexusAppContext {
    private var app: android.content.Context? = null
    fun init(context: android.content.Context) { app = context.applicationContext }
    fun get(): android.content.Context? = app
}
