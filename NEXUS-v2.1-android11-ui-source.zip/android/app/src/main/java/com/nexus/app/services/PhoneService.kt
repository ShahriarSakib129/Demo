package com.nexus.app.services

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.telephony.SmsManager
import androidx.core.app.NotificationCompat
import com.nexus.app.MainActivity
import com.nexus.app.data.Api
import com.nexus.app.data.Session
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject

/**
 * Background bridge service:
 *  - periodic battery reporting to the Core
 *  - phone command polling (find-my-phone, SMS relay) + WebSocket push
 *  - find-my-phone alarm (ring + vibrate)
 */
class PhoneService : Service() {

    private val api = Api()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mainHandler = Handler(Looper.getMainLooper())
    private var ws: WebSocket? = null
    private var alarmStop: Runnable? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIFICATION_ID, buildNotification("NEXUS bridge running"))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_FIND -> stopAlarm()
            else -> {
                startLoops()
                connectWs()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        ws?.close(1000, null)
        scope.cancel()
        stopAlarm()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- loops --
    private fun startLoops() {
        scope.launch {
            while (isActive) {
                reportBattery()
                pollCommands()
                delay(30_000)
            }
        }
    }

    private fun reportBattery() {
        val intent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = intent?.let {
            val raw = it.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = it.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            if (raw >= 0 && scale > 0) (raw * 100 / scale) else null
        }
        val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1)?.let {
            when (it) {
                BatteryManager.BATTERY_STATUS_CHARGING -> "charging"
                BatteryManager.BATTERY_STATUS_DISCHARGING -> "discharging"
                BatteryManager.BATTERY_STATUS_FULL -> "full"
                else -> "idle"
            }
        }
        api.reportBattery(level, status)
    }

    private fun pollCommands() {
        api.pollCommands().onSuccess { commands ->
            commands.forEach { command ->
                runCatching { handleCommand(command.type, command.payload) }
                api.ackCommand(command.id)
            }
        }
    }

    // ------------------------------------------------------------- commands --
    private fun handleCommand(type: String, payload: String) {
        when (type) {
            "find" -> startAlarm()
            "find_stop" -> stopAlarm()
            "sms" -> {
                val json = runCatching { JSONObject(payload) }.getOrNull() ?: return
                sendSms(json.optString("to"), json.optString("text"))
            }
            "open_app" -> {
                val launch = packageManager.getLaunchIntentForPackage(payload) ?: return
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(launch)
            }
        }
    }

    @Suppress("DEPRECATION", "MissingPermission")
    private fun sendSms(to: String, text: String) {
        if (to.isBlank() || text.isBlank()) return
        runCatching {
            val sms = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                getSystemService(SmsManager::class.java)
            else SmsManager.getDefault()
            sms.sendTextMessage(to, null, text, null, null)
        }
    }

    // ---------------------------------------------------------- find alarm --
    @Suppress("DEPRECATION", "MissingPermission")
    private fun startAlarm() {
        val ringtone = RingtoneManager.getRingtone(
            this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        )
        ringtone?.audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM).build()
        ringtone?.play()

        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
            getSystemService(VibratorManager::class.java).defaultVibrator
        else getSystemService(VIBRATOR_SERVICE) as Vibrator
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            vibrator.vibrate(VibrationEffect.createOneShot(30_000, VibrationEffect.DEFAULT_AMPLITUDE))
        else vibrator.vibrate(30_000)

        stopAlarm()
        val stop = Runnable {
            runCatching { ringtone?.stop() }
            vibrator.cancel()
        }
        alarmStop = stop
        mainHandler.postDelayed(stop, 30_000)
    }

    private fun stopAlarm() {
        alarmStop?.let { mainHandler.removeCallbacks(it); it.run() }
        alarmStop = null
    }

    // ---------------------------------------------------------- websocket --
    private fun connectWs() {
        if (!Session.paired()) return
        val token = Session.token ?: return
        val wsUrl = Session.base.replaceFirst("http", "ws") + "/ws?token=$token"
        ws?.close(1000, null)
        ws = OkHttpClient().newWebSocket(
            Request.Builder().url(wsUrl).build(),
            object : WebSocketListener() {
                override fun onMessage(webSocket: WebSocket, text: String) {
                    runCatching {
                        val message = JSONObject(text)
                        if (message.optString("event") == "phone_command") {
                            val payload = message.optJSONObject("payload") ?: return
                            handleCommand(
                                payload.optString("type"),
                                payload.toString()
                            )
                            payload.optInt("id", -1).takeIf { it > 0 }?.let {
                                scope.launch { api.ackCommand(it) }
                            }
                        }
                    }
                }

                override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                    mainHandler.postDelayed({ connectWs() }, 15_000)
                }
            }
        )
    }

    // -------------------------------------------------------- notification --
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "NEXUS bridge", NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        val intent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("NEXUS")
            .setContentText(text)
            .setContentIntent(intent)
            .setOngoing(true)
            .build()
    }

    companion object {
        private const val CHANNEL_ID = "nexus_bridge"
        private const val NOTIFICATION_ID = 42
        const val ACTION_STOP_FIND = "com.nexus.app.STOP_FIND"

        fun start(context: Context) {
            val intent = Intent(context, PhoneService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                context.startForegroundService(intent)
            else context.startService(intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, PhoneService::class.java))
        }
    }
}
