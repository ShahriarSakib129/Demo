package com.nexus.app

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

class NexusNotificationListener : NotificationListenerService() {
    private val client=OkHttpClient()
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val local=getSharedPreferences("nexus_notification",MODE_PRIVATE)
        if(!local.getBoolean("enabled",false) || local.getBoolean("paused",false)) return
        val secure=EncryptedSharedPreferences.create("nexus_secure",MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC),this,EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
        val base=secure.getString("base",null) ?: return; val token=secure.getString("token",null) ?: return
        val title=sbn.notification.extras.getCharSequence("android.title")?.toString().orEmpty(); val text=sbn.notification.extras.getCharSequence("android.text")?.toString().orEmpty()
        GlobalScope.launch(Dispatchers.IO){try{val body=JSONObject(mapOf("source" to sbn.packageName,"title" to title,"text" to text)).toString().toRequestBody("application/json".toMediaType());client.newCall(Request.Builder().url(base.trimEnd('/')+"/notifications").header("Authorization","Bearer $token").post(body).build()).execute().close()}catch(_:Exception){}}
    }
}
