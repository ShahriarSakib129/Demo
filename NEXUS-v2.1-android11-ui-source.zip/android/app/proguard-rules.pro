# Keep OkHttp and security-crypto classes when minification is enabled.
-keep class com.nexus.app.** { *; }
-dontwarn okhttp3.**
-dontwarn org.conscrypt.**
