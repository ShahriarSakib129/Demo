# NEXUS Roadmap

## v2.0 — shipped ✅ (this release)

All of v1.1 + v1.2 + v2.0 delivered in one release train.

### v1.1 — Refactor & Security
- [x] Professional repo layout (routers / core / services / schemas)
- [x] Admin-token protected pairing endpoints (X-Admin-Token)
- [x] FastAPI lifespan (replaces deprecated on_event), SQLite WAL + thread lock
- [x] Structured request validation via pydantic schemas
- [x] Consistent pagination params (limit) on list endpoints
- [x] CI workflow, Dockerfile, hardened systemd unit
- [x] CHANGELOG / CONTRIBUTING / SECURITY docs

### v1.2 — Quick wins
- [x] QR pairing (desktop QR + Android QR scan)
- [x] Phone battery/status reporting on the desktop dashboard
- [x] Share-to-PC (Android share sheet → clipboard/upload)
- [x] Desktop drag & drop upload
- [x] Clipboard history (last 20)
- [x] Find my phone (ring + vibrate, WS + polling)
- [x] Metrics history (48h sampler) with desktop charts
- [x] Notification dismiss/open-on-phone

### v2.0 — Killer features
- [x] WebSocket realtime channel (`/ws`) + polling fallback
- [x] Remote keyboard & mouse (xdotool, virtual touchpad)
- [x] Media control + volume (playerctl/pactl)
- [x] SMS relay via PC → phone
- [x] Resumable chunked upload (`/files/chunk`)
- [x] Photo backup (MediaStore → PC `phone-backup/` folder)
- [x] Automation catalog + cleanup automation
- [x] Device rename + battery column + revocation
- [x] Android foreground bridge service (opt-in)

## v2.1 — next (ideas)
- [ ] Folder sync with conflict handling (true Syncthing-style)
- [ ] Actionable notifications (reply from PC via RemoteInput)
- [ ] Remote screenshot / scrcpy integration
- [ ] Wake-on-LAN
- [ ] Presentation clicker mode
- [ ] Metrics alerts (CPU/RAM thresholds → phone push)

## v3.0 — vision
- [ ] Plugin system (out-of-process, permission-scoped — design in docs/plugins.md)
- [ ] Windows/macOS core support
- [ ] End-to-end encrypted payload layer (age/libsodium) on top of TLS
- [ ] Multi-user profiles with per-device permission scopes
