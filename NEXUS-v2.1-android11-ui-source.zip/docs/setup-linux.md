# Linux setup (v2.0)

## 1. Install

```bash
sudo apt install python3-venv xclip xdotool playerctl pulseaudio-utils   # Debian/Ubuntu
git clone <your-fork> nexus && cd nexus
python3 -m venv .venv && . .venv/bin/activate
pip install -r desktop/requirements.txt
```

Optional tools unlock features: `xclip` (clipboard), `xdotool` (remote input),
`playerctl` (media), `pactl`/`amixer` (volume), `zeroconf` via pip (LAN discovery).

## 2. Run tests & core

```bash
python -m pytest desktop/tests -q
python -m desktop.app.main --core          # API on 0.0.0.0:8765
python -m desktop.app.main --show-admin-token
```

## 3. Desktop console

```bash
python -m desktop.app.main --gui
```

Tabs: **Dashboard** (metrics + charts), **Pairing** (code + QR + approve),
**Devices** (battery, rename/revoke), **Files** (drag & drop), **Logs**.

## 4. Pairing

1. GUI → *Pairing* → **Create pairing code** (QR shown).
2. Phone: install the APK, enter PC URL + code (or scan the QR).
3. GUI: double-click the pending request to approve.

## 5. Firewall

```bash
sudo ufw allow from 192.168.0.0/16 to any port 8765   # LAN only example
```

Never expose 8765 to the internet. For remote access use Tailscale/WireGuard and
enter the overlay IP in the phone (e.g. `http://100.x.y.z:8765`).

## 6. Autostart (systemd)

Copy `systemd/nexus-core.service.example` to `/etc/systemd/system/nexus-core.service`,
adjust `User`, `WorkingDirectory`, `NEXUS_DATA_DIR`, then:

```bash
sudo systemctl enable --now nexus-core
```

## 7. Docker alternative

```bash
docker compose up -d      # host networking for LAN access
```

## Troubleshooting

| Symptom | Fix |
|---|---|
| Clipboard 503 | install `xclip` or `xsel` |
| Input 503 | install `xdotool` |
| Lock fails | run Core inside the graphical session; install `xdg-utils` |
| Phone can't reach PC | check LAN IP, firewall, same network; don't use `localhost` on the phone |
| Discovery fails | install `zeroconf` on Linux; use manual URL otherwise |
