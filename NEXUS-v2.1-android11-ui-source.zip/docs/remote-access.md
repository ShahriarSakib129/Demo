# Remote access

Install Tailscale or WireGuard independently on both devices. Use the Linux private overlay IP in the app. Bind the Core only to the private interface if possible, restrict the firewall, and never expose port 8765 through router port forwarding.
