# Phase 3 + Phase 4

## Android notification mirroring

The app includes a `NotificationListenerService`, an explicit enable switch, and a button that opens Android Notification Access settings. Mirroring is disabled by default and can be paused by turning the switch off. Android system permission is still required. Notification forwarding is intentionally opt-in and should be used only on a trusted/private network.

## LAN discovery

The Linux Core advertises `_nexus._tcp.local.` through Zeroconf when `zeroconf` is installed. Android's **Discover LAN** button searches for this service for five seconds. Manual URL entry remains available when routers block multicast discovery.

## Remote/private mode

For remote use, install Tailscale or WireGuard on both devices and enter the Linux private-overlay address manually, e.g. `http://100.x.y.z:8765` for Tailscale. Do not use public port forwarding. Prefer HTTPS or a private overlay firewall rule. The API remains bearer-token authenticated.

## Background/reconnect limitation

The current Android client performs reconnect-on-action and uses explicit timeout/error states. Persistent Android background execution is intentionally not enabled by default because Android background restrictions and battery policy vary by vendor. A future foreground service can be enabled only with a clear user toggle.
