# Android setup (v2.0)

## Build the APK

```bash
cd android
./gradlew assembleDebug      # app/build/outputs/apk/debug/app-debug.apk
./gradlew assembleRelease    # sign with your keystore for distribution
```

Or open `android/` in Android Studio (Hedgehog+) and press Run.

Requirements: JDK 17+, Android SDK 35. `versionName` 2.0 (`versionCode` 200).

## First run

1. **Connect tab** — enter the Linux Core URL (`http://<pc-lan-ip>:8765`).
2. Enter the 6-digit pairing code from the desktop GUI (or tap **Scan QR**).
3. Tap **Pair**, then approve the request on the desktop.
4. Toggle **Background bridge** for find-my-phone + battery reporting.

## Features

| Tab | Capabilities |
|---|---|
| Connect | pairing (code/QR/discovery), notification permission, background bridge |
| Dashboard | live PC metrics, paired devices + battery |
| Files | list/upload/download/delete, **Backup photos** |
| Control | power (lock/suspend/restart/shutdown), media + volume, keyboard + touchpad |
| Alerts | phone notifications (dismiss/open), find my phone, SMS relay, clipboard |

## Share-to-PC

Use Android's share sheet → **Send to PC** (text goes to the PC clipboard, files upload
to `phone-uploads/` in the shared folder).

## Notes

- Token is stored in EncryptedSharedPreferences (Android Keystore).
- Notification mirroring requires Notification Access (opt-in).
- SMS relay requires the SMS permission (used only for PC-queued messages).
- Cleartext HTTP is enabled for trusted-LAN testing; use Tailscale/WireGuard for remote use.
