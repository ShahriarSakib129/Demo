# Plugin interface (v1.0)

Plugins are documentation/API-ready only in this release; untrusted plugin code is not executed automatically.

A plugin manifest must declare:

```json
{"id":"example","version":"1.0.0","permissions":["metrics:read"]}
```

Allowed permission names are scoped (`metrics:read`, `files:read`, `files:write`, `clipboard:read`, `automation:run`). A future loader must reject undeclared permissions, run plugins out of process, and require explicit user approval. Never install arbitrary plugin code from the phone.
