# Architecture (v2.0)

```text
Android (Kotlin/Compose) ──HTTP + Bearer──▶ FastAPI Core ──▶ SQLite (WAL)
  │  PhoneService (FGS): battery, commands, WS        │
  │  NotificationListener: mirroring                  ├── psutil metrics sampler
Desktop GUI (PySide6) ──admin token─────────────────▶ │
                                                       └── shared dir (files)
```

## Components

| Component | Responsibility |
|---|---|
| `desktop/app/server.py` | FastAPI app factory, lifespan, WebSocket hub |
| `desktop/app/routers/` | one module per feature area (pairing, files, media, …) |
| `desktop/app/core/` | auth (admin/device), rate limiting, WS connection manager |
| `desktop/app/services/` | metrics, files, discovery (mDNS), input (xdotool), media (playerctl) |
| `desktop/app/database.py` | thread-safe SQLite (WAL), all persistence |
| `desktop/app/gui/` | operator console: pairing QR, devices, files, charts |
| `android/` | Compose client + bridge service + notification listener + share receiver |

## Trust model

1. **Admin token** — stays on the Linux machine (`0600` file); authorises pairing and admin views.
2. **Device tokens** — issued after explicit desktop approval; hashed (SHA-256) server-side, stored in Android Keystore-backed prefs.
3. **Filesystem** — all file APIs resolve inside `NEXUS_SHARED_DIR` with strict name/folder validation.
4. **Commands** — power/automation/input use allowlisted actions only; no arbitrary shell execution.
5. **Transport** — trusted LAN or private overlay (Tailscale/WireGuard); TLS via overlay/reverse proxy.

## Data flow: find-my-phone

```text
Desktop POST /phone/find → DB command + WS broadcast
  → PhoneService (WS onMessage | 30s poll) → ringtone + vibrate 30s → ack command
```

## Data flow: notification mirroring

```text
Phone notification → NotificationListenerService → POST /notifications
  → SQLite + WS broadcast → desktop toast / GUI list
Desktop "dismiss/open" → POST /notifications/{id}/dismiss → WS phone_command → phone acts
```

WebSocket events and polling guarantees make the bridge work even when aggressive vendor
battery policies kill sockets — polling is the reliability fallback.
