# Protocol v2.0

Base URL: `http://<linux-host>:8765` (use a Tailscale/WireGuard address for remote use).

## Authentication

| Credential | Header | Used for |
|---|---|---|
| Admin token | `X-Admin-Token: <token>` | pairing management, admin status |
| Device token | `Authorization: Bearer <token>` | everything else |

The admin token is auto-generated into `$NEXUS_DATA_DIR/admin_token` (or `NEXUS_ADMIN_TOKEN`).
Send `Content-Type: application/json` for JSON bodies, multipart for uploads.

## Endpoints

### Public
- `GET /health` — liveness, version, discovery/WS info

### Admin (X-Admin-Token)
- `POST /pairing/create` `{device_name}` → `{request_id, code, expires_in}`
- `GET /pairing/pending` → `{items:[{id, device_name, expires_at}]}`
- `POST /pairing/approve` `{request_id}`
- `GET /admin/status` — shared dir, feature availability

### Pairing
- `POST /pair` `{code, device_name}` → `{device_id, token, name}` (requires desktop approval)

### Devices (Bearer)
- `GET /devices` — list (includes battery_level/status)
- `POST /devices/{id}/revoke`, `POST /devices/{id}/rename` `{name}`
- `POST /device/status` `{level, status}` — phone battery report

### Metrics (Bearer)
- `GET /metrics` — CPU/RAM/disk/network/uptime
- `GET /metrics/history?limit=` — time series samples (30s interval, 48h retention)

### Files (Bearer)
- `GET /files` — recursive listing `{name, folder, size, modified}`
- `POST /files/upload` — multipart `file` + optional `folder`
- `POST /files/chunk` — multipart `upload_id, filename, chunk_index, total_chunks, folder, chunk` (resumable)
- `GET /files/download?name=&folder=`
- `DELETE /files?name=&folder=`

### Clipboard (Bearer)
- `GET /clipboard`, `POST /clipboard` `{text}`, `GET /clipboard/history`

### Notifications (Bearer)
- `GET /notifications`, `POST /notifications` `{source,title,text}`
- `POST /notifications/{id}/dismiss` `{action: "open"|"dismiss"}` — dismiss on phone / open app

### Power / Automation (Bearer, confirm=true required)
- `POST /power/{lock|suspend|restart|shutdown}` `{confirm}`
- `GET /automations`, `POST /automations/run` `{action, confirm}`

### Remote input (Bearer)
- `GET /input/status`
- `POST /input/key` `{key}` (allowlisted: letters, digits, `_+-()` and combos like `ctrl+c`)
- `POST /input/type` `{text}` (≤500 chars)
- `POST /input/mouse` `{action: move|click|right|double|scroll, dx, dy}`

### Media (Bearer)
- `GET /media/status`
- `POST /media/{play|pause|play-pause|next|previous|stop}`
- `POST /media/volume/set` `{level 0-100}`

### Phone commands (Bearer)
- `POST /phone/find` `{duration_seconds}`, `POST /phone/find/stop`
- `POST /sms/send` `{to, text}` — queued for the phone to send
- `GET /phone/commands` — polling fallback for the Android bridge service
- `POST /phone/commands/{id}/ack`

### Realtime
- `WebSocket /ws?token=<device-token>` (or `?admin=<admin-token>`)
- Server events: `notification`, `notification_dismissed`, `pairing_approved`, `phone_command`
- Client → server: `{"event":"ping"}` → `{"event":"pong"}`

### Observability (Bearer)
- `GET /logs?limit=`, `GET /transfers?limit=`

## Rate limiting

240 requests/min per client IP (429 on excess). `/health` and WebSocket are exempt.

## LAN discovery

Advertises `_nexus._tcp.local.` via Zeroconf when installed; Android discovers via NSD.
Remote access is manual-address only through a private Tailscale/WireGuard network — never port-forward 8765.
