# Troubleshooting

- `Connection refused`: start Core and check port 8765.
- Android cannot connect: use the PC LAN/Tailscale IP; Android `localhost` means the phone.
- Pairing rejected: create a fresh code, approve the pending request, and retry before 5 minutes.
- Metrics unavailable: check psutil permissions and platform support.
