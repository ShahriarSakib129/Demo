# NEXUS v1.0 release notes

## Implemented

Authenticated Core API, SQLite persistence, pairing approval, device revocation, file upload/download, transfer history, logs, dashboard metrics, explicit clipboard API, allowlisted power API, safe file-organize automation, Android Keystore token storage, Android notification listener with opt-in forwarding, LAN NSD discovery, Zeroconf advertisement, manual private-network URL fallback, and Android reconnect-on-action.

## Still hardware/network dependent

Android notification access must be enabled by the user; mDNS may be blocked by Wi-Fi client isolation; Tailscale/WireGuard installation and firewall policy are operator tasks; Linux power commands depend on the desktop session and polkit policy.

## Backup

Back up `~/.nexus-data/nexus.sqlite3` and the configured shared folder while the Core is stopped. Tokens are hashes on Linux and cannot be recovered from the database; re-pair a device after restore if necessary.

## Uninstall

Stop the systemd user service if installed, remove the project virtual environment, remove `~/.nexus-data` only if its files are no longer needed, and uninstall the Android app. Remove any custom firewall rule for port 8765.
