"""Core API tests: pairing, auth, files, notifications, power, features."""

from __future__ import annotations

import io

from fastapi.testclient import TestClient

from desktop.app.services.file_service import safe_path


# ------------------------------------------------------------------ health --
def test_health(client: TestClient):
    body = client.get("/health").json()
    assert body["status"] == "ok"
    assert body["version"] == "2.0.0"


# ----------------------------------------------------------------- pairing --
def test_pairing_requires_admin(client: TestClient):
    assert client.post("/pairing/create", json={"device_name": "x"}).status_code == 401
    assert client.get("/pairing/pending").status_code == 401
    assert client.post("/pairing/approve", json={"request_id": "1"}).status_code == 401


def test_pair_requires_approval(client: TestClient, admin_headers: dict):
    item = client.post(
        "/pairing/create", headers=admin_headers, json={"device_name": "test"}
    ).json()
    response = client.post("/pair", json={"code": item["code"], "device_name": "phone"})
    assert response.status_code == 403


def test_pair_after_approval_and_auth(authed):
    client, headers = authed
    assert client.get("/metrics", headers=headers).status_code == 200
    assert client.get("/metrics").status_code == 401
    assert client.get("/devices", headers=headers).status_code == 200


def test_bad_token_rejected(client: TestClient):
    assert (
        client.get("/metrics", headers={"Authorization": "Bearer nope"}).status_code == 401
    )


# ------------------------------------------------------------------- files --
def test_safe_file_path():
    assert safe_path("abc.txt").name == "abc.txt"
    for bad in ("../secret", "/etc/passwd", "a/b.txt", ""):
        try:
            safe_path(bad)
        except ValueError:
            pass
        else:
            assert False, f"accepted unsafe path {bad!r}"


def test_upload_download_delete_roundtrip(authed, client):
    client, headers = authed
    response = client.post(
        "/files/upload",
        headers=headers,
        files={"file": ("hello.txt", io.BytesIO(b"hello nexus"), "text/plain")},
    )
    assert response.status_code == 200
    assert response.json()["name"] == "hello.txt"

    listing = client.get("/files", headers=headers).json()["items"]
    assert any(item["name"] == "hello.txt" for item in listing)

    download = client.get(
        "/files/download", params={"name": "hello.txt"}, headers=headers
    )
    assert download.status_code == 200
    assert download.content == b"hello nexus"

    deleted = client.request(
        "DELETE", "/files", params={"name": "hello.txt"}, headers=headers
    )
    assert deleted.status_code == 200


def test_chunked_upload(authed, client):
    client, headers = authed
    data = b"x" * 100
    for index in range(2):
        part = data[index * 50 : (index + 1) * 50]
        response = client.post(
            "/files/chunk",
            headers=headers,
            data={
                "upload_id": "upload-abc-123",
                "filename": "big.bin",
                "chunk_index": index,
                "total_chunks": 2,
            },
            files={"chunk": (f"c{index}", io.BytesIO(part), "application/octet-stream")},
        )
        assert response.status_code == 200
    final = response.json()
    assert final["complete"] is True
    assert final["size"] == 100


# -------------------------------------------------------- notifications --
def test_notification_roundtrip(authed, client):
    client, headers = authed
    response = client.post(
        "/notifications",
        headers=headers,
        json={"source": "test.app", "title": "Hello", "text": "World"},
    )
    assert response.status_code == 200
    items = client.get("/notifications", headers=headers).json()["items"]
    assert any(item["title"] == "Hello" for item in items)
    assert client.get("/logs", headers=headers).status_code == 200
    assert client.get("/transfers", headers=headers).status_code == 200


# -------------------------------------------------------------- power/input --
def test_power_requires_explicit_confirmation(authed, client):
    client, headers = authed
    response = client.post(
        "/power/restart", headers=headers, json={"confirm": False}
    )
    assert response.status_code == 400
    assert client.post("/power/format-c", headers=headers, json={"confirm": True}).status_code == 400


def test_input_key_validation(authed, client):
    client, headers = authed
    assert (
        client.post("/input/key", headers=headers, json={"key": "Return"}).status_code
        in (200, 503)
    )
    assert (
        client.post("/input/key", headers=headers, json={"key": "rm -rf /"}).status_code
        == 422
    )


# -------------------------------------------------------- battery / phone --
def test_battery_report(authed, client):
    client, headers = authed
    response = client.post(
        "/device/status", headers=headers, json={"level": 77, "status": "charging"}
    )
    assert response.status_code == 200
    devices = client.get("/devices", headers=headers).json()["items"]
    assert devices[0]["battery_level"] == 77


def test_find_phone_queues_command(authed, client):
    client, headers = authed
    response = client.post("/phone/find", headers=headers, json={"duration_seconds": 10})
    assert response.status_code == 200
    commands = client.get("/phone/commands", headers=headers).json()["items"]
    assert any(command["type"] == "find" for command in commands)


# --------------------------------------------------------------- clipboard --
def test_clipboard_history(authed, client):
    client, headers = authed
    response = client.post("/clipboard", headers=headers, json={"text": "copy me"})
    assert response.status_code in (200, 503)
    history = client.get("/clipboard/history", headers=headers)
    assert history.status_code == 200


# ------------------------------------------------------------- automations --
def test_automation_requires_confirm(authed, client):
    client, headers = authed
    response = client.post(
        "/automations/run", headers=headers, json={"action": "organize_shared", "confirm": False}
    )
    assert response.status_code == 400
    response = client.post(
        "/automations/run", headers=headers, json={"action": "nope", "confirm": True}
    )
    assert response.status_code == 400


# ---------------------------------------------------------------- metrics --
def test_metrics_history(authed, client):
    client, headers = authed
    body = client.get("/metrics/history", headers=headers).json()
    assert "items" in body


# ------------------------------------------------------------- admin/status --
def test_admin_status(client: TestClient, admin_headers: dict):
    assert client.get("/admin/status", headers=admin_headers).status_code == 200
    assert client.get("/admin/status").status_code == 401


# --------------------------------------------------------------- cli smoke --
def test_main_module_imports():
    """Regression: desktop.app.main must import (it was untested before v2.0.1)."""
    import importlib

    module = importlib.import_module("desktop.app.main")
    assert callable(module.main)
    from desktop.app.config import admin_token_path

    assert admin_token_path().endswith("admin_token")


# --------------------------------------------------------- db v1 migration --
def test_old_v1_database_migrates(tmp_path):
    """Regression: v1 databases had a 6-column devices table; v2 must upgrade them."""
    import sqlite3

    from desktop.app.database import Database

    legacy = tmp_path / "legacy.sqlite3"
    conn = sqlite3.connect(legacy)
    conn.executescript(
        """
        CREATE TABLE devices(
            id TEXT PRIMARY KEY, name TEXT NOT NULL, token_hash TEXT NOT NULL,
            created_at REAL NOT NULL, last_seen REAL, revoked INTEGER NOT NULL DEFAULT 0);
        INSERT INTO devices VALUES('old1','Old Phone','hash',1.0,1.0,0);
        """
    )
    conn.commit()
    conn.close()

    db = Database(path=legacy)
    did = db.add_device("New Phone", "token-abc")
    assert did
    devices = db.devices()
    assert {d["name"] for d in devices} == {"Old Phone", "New Phone"}
    assert "battery_level" in devices[0]
