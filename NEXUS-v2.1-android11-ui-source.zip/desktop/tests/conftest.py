"""Test fixtures: isolate NEXUS data directory per test session."""

from __future__ import annotations

import os
import tempfile
from pathlib import Path

_tmp = tempfile.mkdtemp(prefix="nexus-test-")
os.environ["NEXUS_DATA_DIR"] = _tmp
os.environ["NEXUS_SHARED_DIR"] = str(Path(_tmp) / "shared")
os.environ["NEXUS_ADMIN_TOKEN"] = "test-admin-token"

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from desktop.app.server import app  # noqa: E402


@pytest.fixture()
def client() -> TestClient:
    return TestClient(app)


@pytest.fixture()
def admin_headers() -> dict:
    return {"X-Admin-Token": "test-admin-token"}


@pytest.fixture()
def authed(client: TestClient, admin_headers: dict):
    """Return (client, auth_headers) with a paired device token."""
    item = client.post(
        "/pairing/create", headers=admin_headers, json={"device_name": "test"}
    ).json()
    client.post(
        "/pairing/approve", headers=admin_headers, json={"request_id": item["request_id"]}
    )
    response = client.post(
        "/pair", json={"code": item["code"], "device_name": "phone"}
    )
    token = response.json()["token"]
    return client, {"Authorization": f"Bearer {token}"}
