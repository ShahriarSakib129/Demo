"""Pydantic request models for the NEXUS Core API."""

from __future__ import annotations

from pydantic import BaseModel, Field


class PairRequest(BaseModel):
    code: str = Field(min_length=6, max_length=6)
    device_name: str = Field(min_length=1, max_length=80)


class ApproveRequest(BaseModel):
    request_id: str = Field(min_length=1, max_length=64)


class CreatePairingRequest(BaseModel):
    device_name: str = Field(default="Android device", min_length=1, max_length=80)


class TextPayload(BaseModel):
    text: str = Field(max_length=10_000)


class PowerPayload(BaseModel):
    confirm: bool = False


class AutomationPayload(BaseModel):
    action: str = Field(min_length=1, max_length=64)
    confirm: bool = False


class NotificationPayload(BaseModel):
    source: str = Field(min_length=1, max_length=160)
    title: str = Field(max_length=300)
    text: str = Field(default="", max_length=2000)


class RenameDeviceRequest(BaseModel):
    name: str = Field(min_length=1, max_length=80)


class BatteryPayload(BaseModel):
    level: int | None = Field(default=None, ge=0, le=100)
    status: str | None = Field(default=None, max_length=32)


class KeyPayload(BaseModel):
    key: str = Field(min_length=1, max_length=32, pattern=r"^[A-Za-z0-9_+()-]+$")


class TypePayload(BaseModel):
    text: str = Field(max_length=500)


class MousePayload(BaseModel):
    action: str = Field(pattern=r"^(move|click|right|double|scroll)$")
    dx: int = Field(default=0, ge=-4000, le=4000)
    dy: int = Field(default=0, ge=-4000, le=4000)


class VolumePayload(BaseModel):
    level: int = Field(ge=0, le=100)


class SmsPayload(BaseModel):
    to: str = Field(min_length=3, max_length=32, pattern=r"^\+?[0-9]+$")
    text: str = Field(max_length=320)


class FindPayload(BaseModel):
    duration_seconds: int = Field(default=30, ge=5, le=120)


class ReplyPayload(BaseModel):
    action: str = Field(default="open", pattern=r"^(open|dismiss)$")
