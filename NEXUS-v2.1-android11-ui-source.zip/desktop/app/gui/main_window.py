"""NEXUS desktop console — pairing, devices, files, metrics and logs."""

from __future__ import annotations

import sys
from pathlib import Path

import requests
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QDragEnterEvent, QDropEvent, QPixmap
from PySide6.QtWidgets import (
    QApplication,
    QFileDialog,
    QHeaderView,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QTabWidget,
    QVBoxLayout,
    QWidget,
    QPlainTextEdit,
)

from ..config import API_VERSION, PORT
from ..core.security import ADMIN_TOKEN, admin_token_path
from .chart import LineChart

try:
    import qrcode
except ImportError:  # pragma: no cover
    qrcode = None


class Console(QMainWindow):
    def __init__(self, base: str | None = None):
        super().__init__()
        self.base = base or f"http://127.0.0.1:{PORT}"
        self.token = ADMIN_TOKEN
        self.setWindowTitle(f"NEXUS Console {API_VERSION}")
        self.resize(920, 680)
        self.setAcceptDrops(True)
        self.setStyleSheet("""
            QMainWindow, QWidget { background: #09090f; color: #f4f1ff; }
            QTabWidget::pane { border: 1px solid #302b42; border-radius: 8px; }
            QTabBar::tab { background: #171722; color: #b9b5cc; padding: 10px 16px;
                           margin: 3px; border-radius: 7px; }
            QTabBar::tab:selected { background: #34205f; color: #ffffff;
                                    border: 1px solid #9b7bff; }
            QPushButton { background: #8b5cf6; color: #ffffff; border: 0;
                          border-radius: 7px; padding: 8px 13px; font-weight: 600; }
            QPushButton:hover { background: #9b7bff; }
            QPushButton:disabled { background: #302b42; color: #888399; }
            QLineEdit, QPlainTextEdit, QListWidget, QTableWidget {
                background: #11111b; color: #f4f1ff; border: 1px solid #393349;
                border-radius: 6px; padding: 5px; selection-background-color: #5b35b5;
            }
            QHeaderView::section { background: #20202d; color: #e9ddff; padding: 7px;
                                   border: 0; }
            QScrollBar:vertical { background: #11111b; width: 10px; }
            QScrollBar::handle:vertical { background: #51416f; border-radius: 4px; }
        """)
        self._build_ui()
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh_all)
        self.timer.start(5000)
        self.refresh_all()

    # ------------------------------------------------------------------ ui --
    def _build_ui(self) -> None:
        self.status = QLabel("Core: …")
        self.url_edit = QLineEdit(self.base)
        self.url_edit.setMaximumWidth(280)
        self.url_edit.editingFinished.connect(self._url_changed)

        header = QHBoxLayout()
        header.addWidget(QLabel(f"<b>NEXUS</b> {API_VERSION}"))
        header.addWidget(self.status)
        header.addStretch(1)
        header.addWidget(QLabel("Core URL"))
        header.addWidget(self.url_edit)

        self.tabs = QTabWidget()
        self.tabs.addTab(self._dashboard_tab(), "Dashboard")
        self.tabs.addTab(self._pairing_tab(), "Pairing")
        self.tabs.addTab(self._devices_tab(), "Devices")
        self.tabs.addTab(self._files_tab(), "Files")
        self.tabs.addTab(self._logs_tab(), "Logs")

        root = QWidget()
        layout = QVBoxLayout(root)
        layout.addLayout(header)
        layout.addWidget(self.tabs)
        self.setCentralWidget(root)

    def _dashboard_tab(self) -> QWidget:
        self.metrics_label = QLabel("No metrics yet")
        self.metrics_label.setWordWrap(True)
        self.cpu_chart = LineChart("CPU %", "#4f8cff")
        self.mem_chart = LineChart("Memory %", "#3fb950")
        self.ram_label = QLabel("")
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.addWidget(self.metrics_label)
        layout.addWidget(self.cpu_chart, 1)
        layout.addWidget(self.mem_chart, 1)
        layout.addWidget(self.ram_label)
        return widget

    def _pairing_tab(self) -> QWidget:
        self.code_label = QLabel("No active pairing code")
        self.code_label.setStyleSheet("font-size: 18px; font-weight: bold;")
        self.qr_label = QLabel()
        self.qr_label.setFixedSize(220, 220)
        self.qr_label.setAlignment(Qt.AlignCenter)
        self.pending = QListWidget()
        self.pending.itemDoubleClicked.connect(self.approve)

        create_btn = QPushButton("Create pairing code")
        create_btn.clicked.connect(self.create_code)
        refresh_btn = QPushButton("Refresh pending")
        refresh_btn.clicked.connect(self.load_pending)

        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.addWidget(QLabel(
            "1) Create a code &nbsp; 2) Enter it on the phone &nbsp; "
            "3) Double-click the request below to approve"
        ))
        row = QHBoxLayout()
        row.addWidget(create_btn)
        row.addWidget(refresh_btn)
        row.addStretch(1)
        layout.addLayout(row)
        layout.addWidget(self.code_label)
        layout.addWidget(self.qr_label)
        layout.addWidget(QLabel("Pending pairings (double-click to approve):"))
        layout.addWidget(self.pending)
        return widget

    def _devices_tab(self) -> QWidget:
        self.devices_table = QTableWidget(0, 5)
        self.devices_table.setHorizontalHeaderLabels(
            ["ID", "Name", "Battery", "Last seen", "Revoked"]
        )
        self.devices_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.devices_table.setSelectionBehavior(QTableWidget.SelectRows)
        revoke_btn = QPushButton("Revoke selected device")
        revoke_btn.clicked.connect(self.revoke_selected)
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.addWidget(self.devices_table)
        layout.addWidget(revoke_btn)
        return widget

    def _files_tab(self) -> QWidget:
        self.files_table = QTableWidget(0, 3)
        self.files_table.setHorizontalHeaderLabels(["Name", "Folder", "Size"])
        self.files_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        upload_btn = QPushButton("Upload file…")
        upload_btn.clicked.connect(self.upload_dialog)
        organize_btn = QPushButton("Organize shared files")
        organize_btn.clicked.connect(lambda: self.run_automation("organize_shared"))
        self.files_hint = QLabel("Tip: drag & drop files anywhere in this window to upload.")
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.addWidget(self.files_table)
        row = QHBoxLayout()
        row.addWidget(upload_btn)
        row.addWidget(organize_btn)
        row.addStretch(1)
        layout.addLayout(row)
        layout.addWidget(self.files_hint)
        return widget

    def _logs_tab(self) -> QWidget:
        self.logs_view = QPlainTextEdit()
        self.logs_view.setReadOnly(True)
        refresh_btn = QPushButton("Refresh logs")
        refresh_btn.clicked.connect(self.load_logs)
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.addWidget(refresh_btn)
        layout.addWidget(self.logs_view)
        return widget

    # -------------------------------------------------------------- helpers --
    def _url_changed(self) -> None:
        self.base = self.url_edit.text().strip().rstrip("/")
        self.refresh_all()

    def _api(self, method: str, path: str, **kwargs):
        headers = kwargs.pop("headers", {})
        headers["X-Admin-Token"] = self.token
        return requests.request(method, self.base + path, headers=headers, timeout=5, **kwargs)

    # -------------------------------------------------------------- actions --
    def refresh_all(self) -> None:
        try:
            health = requests.get(self.base + "/health", timeout=3).json()
            self.status.setText(f"Core: connected (v{health['version']})")
        except Exception:
            self.status.setText("Core: unavailable")
            return
        self.load_pending()
        self.load_devices()
        self.load_files()
        self.load_history()

    def create_code(self) -> None:
        try:
            body = self._api("POST", "/pairing/create", json={"device_name": "Android device"}).json()
        except Exception as exc:
            QMessageBox.warning(self, "NEXUS", str(exc))
            return
        code = body["code"]
        self.code_label.setText(f"Pairing code: {code}  (expires in {body['expires_in']}s)")
        if qrcode:
            image = qrcode.make(code)
            path = Path.cwd() / ".nexus-qr.png"
            image.save(path)
            pixmap = QPixmap(str(path)).scaled(200, 200)
            self.qr_label.setPixmap(pixmap)
        self.load_pending()

    def load_pending(self) -> None:
        self.pending.clear()
        try:
            for item in self._api("GET", "/pairing/pending").json()["items"]:
                self.pending.addItem(f"{item['id']} | {item['device_name']}")
        except Exception:
            pass

    def approve(self, item) -> None:
        rid = item.text().split(" | ")[0]
        try:
            self._api("POST", "/pairing/approve", json={"request_id": rid}).raise_for_status()
            self.load_pending()
            QMessageBox.information(self, "NEXUS", "Pairing approved.")
        except Exception as exc:
            QMessageBox.warning(self, "NEXUS", str(exc))

    def load_devices(self) -> None:
        try:
            items = self._api("GET", "/devices").json()["items"]
        except Exception:
            return
        self.devices_table.setRowCount(len(items))
        for row, item in enumerate(items):
            battery = item.get("battery_level")
            values = [
                item["id"],
                item["name"],
                f"{battery}%" if battery is not None else "—",
                str(int(item.get("last_seen") or 0)),
                "yes" if item["revoked"] else "no",
            ]
            for col, value in enumerate(values):
                self.devices_table.setItem(row, col, QTableWidgetItem(value))

    def revoke_selected(self) -> None:
        row = self.devices_table.currentRow()
        if row < 0:
            return
        did = self.devices_table.item(row, 0).text()
        try:
            self._api("POST", f"/devices/{did}/revoke").raise_for_status()
            self.load_devices()
        except Exception as exc:
            QMessageBox.warning(self, "NEXUS", str(exc))

    def load_files(self) -> None:
        try:
            items = self._api("GET", "/files").json()["items"]
        except Exception:
            return
        self.files_table.setRowCount(len(items))
        for row, item in enumerate(items):
            values = [item["name"], item.get("folder") or "/", f"{item['size']} B"]
            for col, value in enumerate(values):
                self.files_table.setItem(row, col, QTableWidgetItem(value))

    def upload_paths(self, paths: list[str]) -> None:
        for path in paths:
            p = Path(path)
            if not p.is_file():
                continue
            try:
                with p.open("rb") as handle:
                    self._api(
                        "POST",
                        "/files/upload",
                        files={"file": (p.name, handle, "application/octet-stream")},
                    ).raise_for_status()
            except Exception as exc:
                QMessageBox.warning(self, "NEXUS", f"{p.name}: {exc}")
        self.load_files()

    def upload_dialog(self) -> None:
        paths, _ = QFileDialog.getOpenFileNames(self, "Select files")
        if paths:
            self.upload_paths(paths)

    def run_automation(self, action: str) -> None:
        try:
            body = self._api(
                "POST", "/automations/run", json={"action": action, "confirm": True}
            ).json()
            QMessageBox.information(self, "NEXUS", f"Done: {body}")
            self.load_files()
        except Exception as exc:
            QMessageBox.warning(self, "NEXUS", str(exc))

    def load_history(self) -> None:
        try:
            items = self._api("GET", "/metrics/history", params={"limit": 120}).json()["items"]
        except Exception:
            return
        self.cpu_chart.set_values([m["cpu_percent"] for m in items])
        self.mem_chart.set_values([m["memory_percent"] for m in items])
        try:
            current = requests.get(self.base + "/health", timeout=2).json()
            self.ram_label.setText(f"Connected clients (ws): {current.get('ws_clients', 0)}")
        except Exception:
            pass

    def load_logs(self) -> None:
        try:
            items = self._api("GET", "/logs").json()["items"]
        except Exception:
            return
        self.logs_view.setPlainText(
            "\n".join(f"[{int(i['created_at'])}] {i['event']} {i.get('detail','')}" for i in items)
        )

    # ------------------------------------------------------------ dnd support --
    def dragEnterEvent(self, event: QDragEnterEvent) -> None:  # noqa: N802
        if event.mimeData().hasUrls():
            event.acceptProposedAction()

    def dropEvent(self, event: QDropEvent) -> None:  # noqa: N802
        paths = [url.toLocalFile() for url in event.mimeData().urls()]
        self.upload_paths(paths)


def run() -> int:
    app = QApplication(sys.argv)
    window = Console()
    window.show()
    print(f"Admin token file: {admin_token_path()}")
    return app.exec()
