"""Lightweight metric chart widget (no external plotting dependency)."""

from __future__ import annotations

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QColor, QPainter, QPainterPath, QPen
from PySide6.QtWidgets import QWidget


class LineChart(QWidget):
    """Draws a simple filled line chart for a list of floats."""

    def __init__(self, title: str = "", color: str = "#4f8cff", parent=None):
        super().__init__(parent)
        self.title = title
        self.color = QColor(color)
        self.values: list[float] = []
        self.setMinimumHeight(120)

    def set_values(self, values: list[float]) -> None:
        self.values = list(values)
        self.update()

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        rect = QRectF(self.rect()).adjusted(8, 22, -8, -8)

        painter.setPen(QPen(QColor("#c9d1d9"), 1))
        painter.drawText(8, 16, self.title)

        painter.setPen(QPen(QColor("#30363d"), 1))
        painter.drawRect(rect)

        if len(self.values) < 2:
            painter.drawText(rect, Qt.AlignCenter, "No data yet")
            painter.end()
            return

        vmax = max(self.values) or 1.0
        vmin = 0.0
        span = max(vmax - vmin, 1e-6)
        step = rect.width() / (len(self.values) - 1)

        path = QPainterPath()
        for index, value in enumerate(self.values):
            x = rect.left() + index * step
            y = rect.bottom() - (value - vmin) / span * rect.height() * 0.92
            if index == 0:
                path.moveTo(QPointF(x, y))
            else:
                path.lineTo(QPointF(x, y))

        fill = QPainterPath(path)
        fill.lineTo(rect.right(), rect.bottom())
        fill.lineTo(rect.left(), rect.bottom())
        fill.closeSubpath()

        fill_color = QColor(self.color)
        fill_color.setAlpha(60)
        painter.fillPath(fill, fill_color)
        painter.setPen(QPen(self.color, 2))
        painter.drawPath(path)

        painter.setPen(QColor("#8b949e"))
        painter.drawText(
            rect.adjusted(6, 4, -6, -4),
            Qt.AlignLeft | Qt.AlignTop,
            f"{self.values[-1]:.1f}",
        )
        painter.end()
