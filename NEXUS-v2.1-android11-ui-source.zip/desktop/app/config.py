"""NEXUS Core configuration.

All paths and limits are resolved once at import time from environment
variables so the service can be relocated without code changes.
"""

from __future__ import annotations

import os
import stat
from pathlib import Path

APP_NAME = "NEXUS"
API_VERSION = "2.0.0"

# ---------------------------------------------------------------- storage ---
DATA_DIR = Path(os.getenv("NEXUS_DATA_DIR", Path.home() / ".nexus-data"))
DATA_DIR.mkdir(parents=True, exist_ok=True)

DB_PATH = DATA_DIR / "nexus.sqlite3"

SHARED_DIR = Path(os.getenv("NEXUS_SHARED_DIR", DATA_DIR / "shared"))
SHARED_DIR.mkdir(parents=True, exist_ok=True)

CHUNK_DIR = DATA_DIR / "chunks"
CHUNK_DIR.mkdir(parents=True, exist_ok=True)

# ---------------------------------------------------------------- network ---
# Secure default: local-only. Explicitly set NEXUS_BIND to a LAN address
# only after reviewing firewall and remote-access guidance.
BIND = os.getenv("NEXUS_BIND", "127.0.0.1")
PORT = int(os.getenv("NEXUS_PORT", "8765"))

# ---------------------------------------------------------------- security --
PAIRING_TTL = int(os.getenv("NEXUS_PAIRING_TTL", "300"))
MAX_FILE_BYTES = int(os.getenv("NEXUS_MAX_FILE_BYTES", str(200 * 1024 * 1024)))
RATE_LIMIT_REQUESTS = int(os.getenv("NEXUS_RATE_LIMIT", "240"))
RATE_LIMIT_WINDOW = 60
MAX_CLIPBOARD_CHARS = 10_000
MAX_TYPE_CHARS = 500
NOTIFICATION_RETENTION = 100
CLIPBOARD_HISTORY_SIZE = 20
METRICS_HISTORY_RETENTION_HOURS = 48
METRICS_SAMPLE_SECONDS = 30

ADMIN_TOKEN_FILE = DATA_DIR / "admin_token"


def admin_token_path() -> str:
    """Path of the persisted admin token file."""
    return str(ADMIN_TOKEN_FILE)


def load_or_create_admin_token() -> str:
    """Return the admin token, generating and persisting one on first run."""
    env = os.getenv("NEXUS_ADMIN_TOKEN")
    if env:
        return env.strip()
    if ADMIN_TOKEN_FILE.exists():
        return ADMIN_TOKEN_FILE.read_text().strip()
    import secrets

    token = secrets.token_urlsafe(24)
    ADMIN_TOKEN_FILE.write_text(token + "\n")
    try:
        ADMIN_TOKEN_FILE.chmod(stat.S_IRUSR | stat.S_IWUSR)
    except OSError:
        pass
    return token
