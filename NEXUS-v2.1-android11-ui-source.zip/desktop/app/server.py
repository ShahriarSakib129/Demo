"""NEXUS Core — FastAPI application factory."""

from __future__ import annotations

import json
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request, WebSocket, WebSocketDisconnect

from .config import API_VERSION
from .core.deps import get_db, set_db
from .core.security import rate_limit_check, verify_admin_token
from .core.ws import manager
from .database import Database
from .routers import (
    admin,
    automations,
    clipboard,
    devices,
    files,
    input,
    media,
    metrics,
    notifications,
    pairing,
    phone,
    power,
)
from .services.discovery import Discovery
from .services.metrics_sampler import MetricsSampler

db = Database()
set_db(db)
discovery = Discovery()
sampler = MetricsSampler(db)

PUBLIC_PATHS = {"/health", "/docs", "/openapi.json", "/redoc"}


@asynccontextmanager
async def lifespan(app: FastAPI):
    discovery.start()
    sampler.start()
    db.cleanup()
    yield
    sampler.stop()
    discovery.stop()


app = FastAPI(
    title="NEXUS Core",
    version=API_VERSION,
    description="Private, local-first bridge between Android and Linux.",
    lifespan=lifespan,
)


@app.middleware("http")
async def rate_limit(request: Request, call_next):
    if request.url.path not in PUBLIC_PATHS and not request.url.path.startswith("/ws"):
        rate_limit_check(request.client.host if request.client else None)
    return await call_next(request)


@app.get("/health")
def health() -> dict:
    return {
        "status": "ok",
        "version": API_VERSION,
        "discovery": "enabled" if discovery.zc else "unavailable",
        "remote_mode": "private-overlay-ready",
        "ws_clients": manager.count,
    }


@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket) -> None:
    """Realtime channel. Auth: ?token=<device-token> or ?admin=<admin-token>."""
    token = ws.query_params.get("token")
    admin_token = ws.query_params.get("admin")
    authorized = False
    if admin_token and verify_admin_token(admin_token):
        authorized = True
    elif token and db.device_by_token(token):
        authorized = True
    if not authorized:
        await ws.close(code=4401)
        return
    await manager.connect(ws)
    try:
        while True:
            raw = await ws.receive_text()
            try:
                message = json.loads(raw)
            except json.JSONDecodeError:
                continue
            if message.get("event") == "ping":
                await ws.send_text(json.dumps({"event": "pong"}))
    except WebSocketDisconnect:
        pass
    finally:
        await manager.disconnect(ws)


for router in (
    pairing.router,
    devices.router,
    metrics.router,
    files.router,
    clipboard.router,
    notifications.router,
    power.router,
    input.router,
    media.router,
    phone.router,
    automations.router,
    admin.router,
):
    app.include_router(router)
