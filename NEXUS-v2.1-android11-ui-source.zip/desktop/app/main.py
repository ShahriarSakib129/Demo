"""CLI entrypoint: run the NEXUS Core server or the desktop GUI."""

from __future__ import annotations

import argparse

import uvicorn

from .config import API_VERSION, BIND, PORT, admin_token_path
from .core.security import ADMIN_TOKEN


def main() -> None:
    parser = argparse.ArgumentParser(prog="nexus", description="NEXUS Core")
    parser.add_argument("--core", action="store_true", help="run the API server")
    parser.add_argument("--gui", action="store_true", help="run the desktop GUI")
    parser.add_argument("--host", default=BIND)
    parser.add_argument("--port", type=int, default=PORT)
    parser.add_argument("--show-admin-token", action="store_true")
    args = parser.parse_args()

    if args.show_admin_token:
        print(f"Admin token ({admin_token_path()}): {ADMIN_TOKEN}")
        return

    if args.gui:
        from .gui.main_window import run

        raise SystemExit(run())

    print(f"NEXUS Core {API_VERSION} -> http://{args.host}:{args.port}")
    print(f"Admin token file: {admin_token_path()}")
    uvicorn.run("desktop.app.server:app", host=args.host, port=args.port, reload=False)


if __name__ == "__main__":
    main()
