"""Authentication, rate limiting and small security helpers."""

from __future__ import annotations

import hmac
import secrets
import time
from collections import defaultdict, deque

from fastapi import HTTPException

from ..config import (
    RATE_LIMIT_REQUESTS,
    RATE_LIMIT_WINDOW,
    admin_token_path,
    load_or_create_admin_token,
)

ADMIN_TOKEN = load_or_create_admin_token()

_hits: dict[str, deque[float]] = defaultdict(deque)


def device_auth(authorization: str | None, db) -> dict:
    """Validate a device bearer token and return the device row."""
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(401, "Authentication required")
    token = authorization[7:].strip()
    row = db.device_by_token(token)
    if not row:
        raise HTTPException(401, "Invalid or revoked token")
    return row


def admin_auth(x_admin_token: str | None) -> None:
    """Validate the desktop/admin token used for pairing management."""
    if not x_admin_token or not hmac.compare_digest(x_admin_token.strip(), ADMIN_TOKEN):
        raise HTTPException(401, "Admin token required")


def verify_admin_token(candidate: str | None) -> bool:
    return bool(candidate) and hmac.compare_digest(candidate.strip(), ADMIN_TOKEN)


def rate_limit_check(host: str | None) -> None:
    key = host or "unknown"
    now = time.time()
    q = _hits[key]
    while q and q[0] < now - RATE_LIMIT_WINDOW:
        q.popleft()
    if len(q) >= RATE_LIMIT_REQUESTS:
        raise HTTPException(429, "Too many requests; retry later")
    q.append(now)


def new_device_token() -> str:
    return secrets.token_urlsafe(32)
