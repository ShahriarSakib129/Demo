"""Core package: auth, security, websocket manager."""
