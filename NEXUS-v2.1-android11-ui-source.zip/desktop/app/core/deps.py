"""FastAPI dependency helpers."""

from __future__ import annotations

from fastapi import Depends, Header

from ..database import Database
from .security import admin_auth, device_auth

_db: Database | None = None


def set_db(db: Database) -> None:
    global _db
    _db = db


def get_db() -> Database:
    if _db is None:  # pragma: no cover - defensive
        raise RuntimeError("Database not initialised")
    return _db


def require_device(authorization: str | None = Header(default=None)) -> dict:
    return device_auth(authorization, get_db())


def require_admin(x_admin_token: str | None = Header(default=None)) -> None:
    admin_auth(x_admin_token)


DeviceDep = Depends(require_device)
AdminDep = Depends(require_admin)
