"""Allowlisted power actions (no arbitrary shell execution)."""

from __future__ import annotations

import os
import shutil
import subprocess

from fastapi import APIRouter, Depends, HTTPException

from ..core.deps import get_db, require_device
from ..schemas import PowerPayload

router = APIRouter(tags=["power"])

COMMANDS = {
    "suspend": ["systemctl", "suspend"],
    "restart": ["systemctl", "reboot"],
    "shutdown": ["systemctl", "poweroff"],
}


@router.post("/power/{action}")
def power(action: str, body: PowerPayload, _device: dict = Depends(require_device)) -> dict:
    if action != "lock" and action not in COMMANDS:
        raise HTTPException(400, "Unsupported power action")
    if not body.confirm:
        raise HTTPException(400, "Explicit confirmation required")
    db = get_db()
    db.log("power_requested", action)
    try:
        if action == "lock":
            session = os.environ.get("XDG_SESSION_ID")
            attempts = []
            if session:
                attempts.append(["loginctl", "--no-ask-password", "lock-session", session])
            attempts += [
                ["xdg-screensaver", "lock"],
                ["gnome-screensaver-command", "--lock"],
                ["dm-tool", "lock"],
            ]
            for command in attempts:
                if shutil.which(command[0]):
                    result = subprocess.run(
                        command, timeout=5, capture_output=True, text=True
                    )
                    if result.returncode == 0:
                        return {"accepted": True, "action": action}
            raise RuntimeError(
                "No desktop lock command succeeded; try installing xdg-utils "
                "or run from the graphical user session"
            )
        subprocess.Popen(COMMANDS[action], start_new_session=True)
    except Exception as exc:
        raise HTTPException(500, f"Power action failed: {exc}")
    return {"accepted": True, "action": action}
