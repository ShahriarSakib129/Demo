"""Shared-folder file management: upload, chunked upload, download, delete."""

from __future__ import annotations

import shutil
from pathlib import Path

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse

from ..config import CHUNK_DIR, MAX_FILE_BYTES, SHARED_DIR
from ..core.deps import get_db, require_device
from ..services.file_service import list_files, safe_path, safe_upload_id

router = APIRouter(tags=["files"])


@router.get("/files")
def files(_device: dict = Depends(require_device)) -> dict:
    return {"items": list_files()}


@router.post("/files/upload")
async def upload(
    file: UploadFile = File(...),
    folder: str | None = Form(default=None),
    _device: dict = Depends(require_device),
) -> dict:
    db = get_db()
    try:
        p = safe_path(file.filename or "unnamed", folder or None)
    except ValueError:
        raise HTTPException(400, "Invalid filename or folder")
    total = 0
    tmp = p.with_suffix(p.suffix + ".part")
    try:
        with tmp.open("wb") as out:
            while chunk := await file.read(1024 * 1024):
                total += len(chunk)
                if total > MAX_FILE_BYTES:
                    raise HTTPException(413, "File exceeds size limit")
                out.write(chunk)
        tmp.replace(p)
        db.transfer(p.name, total, "upload", "complete")
        return {"name": p.name, "folder": folder or "", "size": total}
    except HTTPException:
        tmp.unlink(missing_ok=True)
        raise
    except Exception:
        tmp.unlink(missing_ok=True)
        raise HTTPException(500, "Upload failed")


@router.post("/files/chunk")
async def upload_chunk(
    upload_id: str = Form(...),
    filename: str = Form(...),
    chunk_index: int = Form(...),
    total_chunks: int = Form(...),
    folder: str | None = Form(default=None),
    chunk: UploadFile = File(...),
    _device: dict = Depends(require_device),
) -> dict:
    """Resumable chunked upload for large files (used by the Android client)."""
    if chunk_index < 0 or chunk_index >= total_chunks or total_chunks > 4096:
        raise HTTPException(400, "Invalid chunk index")
    try:
        dir_path = safe_upload_id(upload_id)
        final = safe_path(filename, folder or None)
    except ValueError:
        raise HTTPException(400, "Invalid upload id or filename")
    part = dir_path / f"{chunk_index:05d}.part"
    size = 0
    with part.open("wb") as out:
        while data := await chunk.read(1024 * 1024):
            size += len(data)
            out.write(data)
    received = sum(f.stat().st_size for f in dir_path.glob("*.part"))
    if received > MAX_FILE_BYTES:
        shutil.rmtree(dir_path, ignore_errors=True)
        raise HTTPException(413, "File exceeds size limit")
    if chunk_index == total_chunks - 1:
        # Assemble on the last chunk.
        with final.open("wb") as out:
            for i in range(total_chunks):
                part_file = dir_path / f"{i:05d}.part"
                if not part_file.exists():
                    shutil.rmtree(dir_path, ignore_errors=True)
                    raise HTTPException(400, f"Missing chunk {i}")
                with part_file.open("rb") as src:
                    shutil.copyfileobj(src, out)
        total = final.stat().st_size
        shutil.rmtree(dir_path, ignore_errors=True)
        get_db().transfer(final.name, total, "upload", "complete")
        return {"name": final.name, "size": total, "complete": True}
    return {"received_chunks": chunk_index + 1, "total_chunks": total_chunks, "complete": False}


@router.get("/files/download")
def download(
    name: str,
    folder: str | None = None,
    _device: dict = Depends(require_device),
):
    db = get_db()
    try:
        p = safe_path(name, folder or None)
    except ValueError:
        raise HTTPException(400, "Invalid filename")
    if not p.exists():
        raise HTTPException(404, "File not found")
    db.transfer(p.name, p.stat().st_size, "download", "complete")
    return FileResponse(p, filename=p.name)


@router.delete("/files")
def delete_file(
    name: str,
    folder: str | None = None,
    _device: dict = Depends(require_device),
) -> dict:
    try:
        p = safe_path(name, folder or None)
    except ValueError:
        raise HTTPException(400, "Invalid filename")
    if not p.exists():
        raise HTTPException(404, "File not found")
    p.unlink()
    get_db().log("file_deleted", p.name)
    return {"deleted": True}
