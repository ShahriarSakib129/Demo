"""Commands targeting the paired phone: find-my-phone, SMS, quick actions."""

from __future__ import annotations

from fastapi import APIRouter, Depends

from ..core.deps import get_db, require_device
from ..core.ws import manager
from ..schemas import FindPayload, SmsPayload

router = APIRouter(tags=["phone"])


@router.post("/phone/find")
async def find_phone(
    body: FindPayload, device: dict = Depends(require_device)
) -> dict:
    """Queue a find-my-phone command; the phone rings/vibrates when picked up."""
    db = get_db()
    cid = db.add_command(
        "find", f'{{"duration_seconds": {body.duration_seconds}}}', device_id=None
    )
    db.log("find_phone_requested", f"device={device['id']}")
    await manager.broadcast(
        "phone_command",
        {"type": "find", "duration_seconds": body.duration_seconds, "id": cid},
    )
    return {"queued": True, "command_id": cid}


@router.post("/phone/find/stop")
async def stop_find(device: dict = Depends(require_device)) -> dict:
    db = get_db()
    cid = db.add_command("find_stop", "", device_id=None)
    await manager.broadcast("phone_command", {"type": "find_stop", "id": cid})
    return {"queued": True, "command_id": cid}


@router.post("/sms/send")
async def send_sms(body: SmsPayload, device: dict = Depends(require_device)) -> dict:
    """Queue an SMS for the phone to send (requires SMS permission on Android)."""
    db = get_db()
    payload = f'{{"to": "{body.to}", "text": {body.text!r}}}'
    cid = db.add_command("sms", payload, device_id=None)
    db.log("sms_queued", f"to={body.to} device={device['id']}")
    await manager.broadcast("phone_command", {"type": "sms", "to": body.to, "text": body.text, "id": cid})
    return {"queued": True, "command_id": cid}


@router.get("/phone/commands")
def poll_commands(device: dict = Depends(require_device)) -> dict:
    """Polling fallback so the phone does not need a persistent socket."""
    return {"items": get_db().pending_commands(device_id=device["id"])}


@router.post("/phone/commands/{command_id}/ack")
def ack_command(command_id: int, _device: dict = Depends(require_device)) -> dict:
    get_db().ack_command(command_id)
    return {"acked": True}
