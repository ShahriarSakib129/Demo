"""Remote keyboard/mouse input (xdotool, allowlisted)."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

from ..config import MAX_TYPE_CHARS
from ..core.deps import get_db, require_device
from ..schemas import KeyPayload, MousePayload, TypePayload
from ..services.input_service import InputService

router = APIRouter(tags=["input"])


def _require_xdotool() -> None:
    if not InputService.available():
        raise HTTPException(503, "Install xdotool to enable remote input controls")


@router.get("/input/status")
def input_status(_device: dict = Depends(require_device)) -> dict:
    return {"available": InputService.available()}


@router.post("/input/key")
def press_key(body: KeyPayload, device: dict = Depends(require_device)) -> dict:
    _require_xdotool()
    if not InputService.key(body.key):
        raise HTTPException(500, "Key press failed")
    get_db().log("input_key", f"device={device['id']} key={body.key}")
    return {"sent": True}


@router.post("/input/type")
def type_text(body: TypePayload, device: dict = Depends(require_device)) -> dict:
    _require_xdotool()
    text = body.text[:MAX_TYPE_CHARS]
    if not InputService.type_text(text):
        raise HTTPException(500, "Typing failed")
    get_db().log("input_type", f"device={device['id']} length={len(text)}")
    return {"sent": True, "length": len(text)}


@router.post("/input/mouse")
def mouse(body: MousePayload, device: dict = Depends(require_device)) -> dict:
    _require_xdotool()
    if not InputService.mouse(body.action, body.dx, body.dy):
        raise HTTPException(500, "Mouse action failed")
    return {"sent": True, "action": body.action}
