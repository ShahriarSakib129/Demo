"""Clipboard read/write (xclip/xsel) with server-side history."""

from __future__ import annotations

import shutil
import subprocess

from fastapi import APIRouter, Depends, HTTPException

from ..config import CLIPBOARD_HISTORY_SIZE
from ..core.deps import get_db, require_device
from ..schemas import TextPayload

router = APIRouter(tags=["clipboard"])


def _reader() -> list[str] | None:
    if shutil.which("xclip"):
        return ["xclip", "-selection", "clipboard", "-o"]
    if shutil.which("xsel"):
        return ["xsel", "--clipboard", "--output"]
    return None


def _writer() -> list[str] | None:
    if shutil.which("xclip"):
        return ["xclip", "-selection", "clipboard"]
    if shutil.which("xsel"):
        return ["xsel", "--clipboard", "--input"]
    return None


@router.get("/clipboard")
def clipboard_get(_device: dict = Depends(require_device)) -> dict:
    cmd = _reader()
    if not cmd:
        return {
            "available": False,
            "text": "",
            "message": "Install xclip or xsel to enable clipboard controls",
        }
    try:
        text = subprocess.check_output(cmd, text=True, timeout=2)
    except Exception:
        text = ""
    return {"available": True, "text": text}


@router.post("/clipboard")
def clipboard_set(body: TextPayload, _device: dict = Depends(require_device)) -> dict:
    cmd = _writer()
    if not cmd:
        raise HTTPException(503, "Install xclip or xsel to enable clipboard controls")
    try:
        subprocess.run(cmd, input=body.text, text=True, timeout=2, check=True)
    except Exception:
        raise HTTPException(500, "Clipboard update failed")
    db = get_db()
    db.add_clipboard(body.text)
    db.log("clipboard_set", f"text_length={len(body.text)}")
    return {"updated": True}


@router.get("/clipboard/history")
def clipboard_history(
    limit: int = CLIPBOARD_HISTORY_SIZE, _device: dict = Depends(require_device)
) -> dict:
    return {"items": get_db().clipboard_history(limit=limit)}
