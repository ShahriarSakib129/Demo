"""Host metrics (current + historical)."""

from __future__ import annotations

from fastapi import APIRouter, Depends, Query

from ..core.deps import get_db, require_device
from ..services.system_monitor import metrics

router = APIRouter(tags=["metrics"])


@router.get("/metrics")
def get_metrics(_device: dict = Depends(require_device)) -> dict:
    return metrics()


@router.get("/metrics/history")
def history(
    limit: int = Query(default=2880, ge=1, le=10000),
    _device: dict = Depends(require_device),
) -> dict:
    return {"items": get_db().metrics_history(limit=limit)}
