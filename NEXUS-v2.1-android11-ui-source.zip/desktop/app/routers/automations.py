"""Safe, allowlisted automations."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

from ..config import SHARED_DIR
from ..core.deps import get_db, require_device
from ..schemas import AutomationPayload

router = APIRouter(tags=["automations"])

CATALOG = [
    {
        "id": "organize_shared",
        "label": "Organize shared files by extension",
        "dangerous": False,
    },
    {
        "id": "cleanup_partials",
        "label": "Remove leftover .part upload files",
        "dangerous": False,
    },
]


@router.get("/automations")
def automations(_device: dict = Depends(require_device)) -> dict:
    return {"items": CATALOG}


@router.post("/automations/run")
def run_automation(
    body: AutomationPayload, device: dict = Depends(require_device)
) -> dict:
    db = get_db()
    if body.action not in {item["id"] for item in CATALOG}:
        raise HTTPException(400, "Unknown or disallowed automation")
    if not body.confirm:
        raise HTTPException(400, "Explicit confirmation required")

    moved = 0
    if body.action == "organize_shared":
        for p in list(SHARED_DIR.iterdir()):
            if p.is_file() and not p.name.endswith(".part"):
                folder = SHARED_DIR / (p.suffix[1:].lower() or "other")
                folder.mkdir(exist_ok=True)
                p.rename(folder / p.name)
                moved += 1
    elif body.action == "cleanup_partials":
        for p in SHARED_DIR.rglob("*.part"):
            p.unlink(missing_ok=True)
            moved += 1

    db.log("automation_run", f"{body.action} moved={moved} device={device['id']}")
    return {"action": body.action, "moved": moved}
