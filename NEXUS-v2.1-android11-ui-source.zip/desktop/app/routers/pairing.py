"""Pairing flow: admin-protected code creation + device token exchange."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException

from ..config import PAIRING_TTL
from ..core.deps import get_db, require_admin
from ..core.security import new_device_token
from ..schemas import ApproveRequest, CreatePairingRequest, PairRequest
from ..core.ws import manager
from fastapi import Depends

router = APIRouter(tags=["pairing"])


@router.post("/pairing/create", dependencies=[Depends(require_admin)])
def create_pairing(body: CreatePairingRequest | None = None) -> dict:
    """Desktop-only: mint a short-lived 6-digit pairing code."""
    name = (body.device_name if body else "Android device").strip()
    rid, code = get_db().create_pairing(name, PAIRING_TTL)
    return {"request_id": rid, "code": code, "expires_in": PAIRING_TTL}


@router.get("/pairing/pending", dependencies=[Depends(require_admin)])
def pending() -> dict:
    return {"items": get_db().pending_pairings()}


@router.post("/pairing/approve", dependencies=[Depends(require_admin)])
async def approve(body: ApproveRequest) -> dict:
    if not get_db().approve_pairing(body.request_id):
        raise HTTPException(404, "Pairing request expired or not found")
    await manager.broadcast("pairing_approved", {"request_id": body.request_id})
    return {"approved": True}


@router.post("/pair")
def pair(body: PairRequest) -> dict:
    """Android exchanges an approved code for a bearer token."""
    db = get_db()
    row = db.verify_code(body.code)
    if not row:
        raise HTTPException(401, "Invalid or expired pairing code")
    if not row["approved"]:
        raise HTTPException(403, "Pairing requires desktop approval")
    token = new_device_token()
    did = db.add_device(body.device_name.strip(), token)
    db.consume_pairing(row["id"])
    return {"device_id": did, "token": token, "name": body.device_name.strip()}
