"""Admin/observability endpoints (logs, transfers, service status)."""

from __future__ import annotations

from fastapi import APIRouter, Depends, Query

from ..config import API_VERSION, SHARED_DIR
from ..core.deps import get_db, require_admin, require_device
from ..core.security import admin_token_path
from ..core.ws import manager
from ..services.input_service import InputService
from ..services.media_service import MediaService

router = APIRouter(tags=["admin"])


@router.get("/logs")
def logs(limit: int = Query(default=200, ge=1, le=1000), _device: dict = Depends(require_device)) -> dict:
    return {"items": get_db().logs(limit=limit)}


@router.get("/transfers")
def transfers(limit: int = Query(default=100, ge=1, le=1000), _device: dict = Depends(require_device)) -> dict:
    return {"items": get_db().transfers(limit=limit)}


@router.get("/admin/status", dependencies=[Depends(require_admin)])
def admin_status() -> dict:
    db = get_db()
    return {
        "api_version": API_VERSION,
        "shared_dir": str(SHARED_DIR),
        "admin_token_file": admin_token_path(),
        "devices": len(db.devices()),
        "ws_clients": manager.count,
        "features": {
            "discovery": "zeroconf",
            "remote_input": InputService.available(),
            "media_control": MediaService.available(),
        },
    }
