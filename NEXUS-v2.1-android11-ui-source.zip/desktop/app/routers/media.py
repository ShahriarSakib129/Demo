"""Media playback control (playerctl) and volume (pactl/amixer)."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

from ..core.deps import get_db, require_device
from ..schemas import VolumePayload
from ..services.media_service import MediaService

router = APIRouter(tags=["media"])


@router.get("/media/status")
def media_status(_device: dict = Depends(require_device)) -> dict:
    return MediaService.status()


@router.post("/media/{action}")
def media_action(action: str, device: dict = Depends(require_device)) -> dict:
    if not MediaService.control(action):
        raise HTTPException(400, "Unsupported media action or playerctl unavailable")
    get_db().log("media_action", f"device={device['id']} action={action}")
    return {"ok": True, "action": action}


@router.post("/media/volume/set")
def set_volume(body: VolumePayload, device: dict = Depends(require_device)) -> dict:
    if not MediaService.set_volume(body.level):
        raise HTTPException(503, "Install pactl or amixer to control volume")
    get_db().log("volume_set", f"device={device['id']} level={body.level}")
    return {"ok": True, "level": body.level}
