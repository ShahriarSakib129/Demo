"""Phone notification mirroring."""

from __future__ import annotations

from fastapi import APIRouter, Depends

from ..core.deps import get_db, require_device
from ..core.ws import manager
from ..schemas import NotificationPayload, ReplyPayload

router = APIRouter(tags=["notifications"])


@router.get("/notifications")
def notifications(_device: dict = Depends(require_device)) -> dict:
    return {"items": get_db().notifications()}


@router.post("/notifications")
async def receive(
    body: NotificationPayload, _device: dict = Depends(require_device)
) -> dict:
    db = get_db()
    nid = db.add_notification(body.source, body.title, body.text)
    await manager.broadcast(
        "notification", {"id": nid, "source": body.source, "title": body.title, "text": body.text}
    )
    return {"received": True, "id": nid}


@router.post("/notifications/{notification_id}/dismiss")
async def dismiss(
    notification_id: int,
    body: ReplyPayload | None = None,
    device: dict = Depends(require_device),
) -> dict:
    db = get_db()
    db.dismiss_notification(notification_id)
    action = body.action if body else "dismiss"
    if action == "open":
        # Ask the phone to bring the source app to the foreground.
        rows = [n for n in db.notifications(limit=500) if n["id"] == notification_id]
        source = rows[0]["source"] if rows else ""
        db.add_command("open_app", source, device_id=None)
        await manager.broadcast("phone_command", {"type": "open_app", "payload": source})
    await manager.broadcast("notification_dismissed", {"id": notification_id})
    return {"dismissed": True, "action": action}
