"""Device management: listing, revocation, renaming and battery status."""

from __future__ import annotations

from fastapi import APIRouter, Depends

from ..core.deps import get_db, require_device
from ..schemas import BatteryPayload, RenameDeviceRequest

router = APIRouter(tags=["devices"])


@router.get("/devices")
def devices(_device: dict = Depends(require_device)) -> dict:
    return {"items": get_db().devices()}


@router.post("/devices/{device_id}/revoke")
def revoke(device_id: str, _device: dict = Depends(require_device)) -> dict:
    get_db().revoke_device(device_id)
    return {"revoked": True}


@router.post("/devices/{device_id}/rename")
def rename(
    device_id: str, body: RenameDeviceRequest, _device: dict = Depends(require_device)
) -> dict:
    get_db().rename_device(device_id, body.name.strip())
    return {"renamed": True, "name": body.name.strip()}


@router.post("/device/status")
def report_status(
    body: BatteryPayload, device: dict = Depends(require_device)
) -> dict:
    """Android reports its battery level/status here."""
    get_db().update_battery(device["id"], body.level, body.status)
    return {"received": True}
