"""SQLite persistence layer for NEXUS Core.

A single connection guarded by a lock is sufficient for this LAN-scale
service. WAL mode keeps readers and the background metrics sampler happy.
"""

from __future__ import annotations

import hashlib
import secrets
import sqlite3
import threading
import time
from pathlib import Path
from typing import Any

from .config import (
    CLIPBOARD_HISTORY_SIZE,
    DB_PATH,
    METRICS_HISTORY_RETENTION_HOURS,
    NOTIFICATION_RETENTION,
)

SCHEMA = """
CREATE TABLE IF NOT EXISTS devices(
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    token_hash TEXT NOT NULL,
    created_at REAL NOT NULL,
    last_seen REAL,
    revoked INTEGER NOT NULL DEFAULT 0,
    battery_level INTEGER,
    battery_status TEXT,
    last_battery_update REAL
);
CREATE TABLE IF NOT EXISTS pairing_requests(
    id TEXT PRIMARY KEY,
    code_hash TEXT NOT NULL,
    created_at REAL NOT NULL,
    expires_at REAL NOT NULL,
    approved INTEGER NOT NULL DEFAULT 0,
    device_name TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS transfers(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    filename TEXT NOT NULL,
    size INTEGER NOT NULL,
    direction TEXT NOT NULL,
    created_at REAL NOT NULL,
    status TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS logs(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    event TEXT NOT NULL,
    detail TEXT,
    created_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS notifications(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source TEXT NOT NULL,
    title TEXT NOT NULL,
    text TEXT,
    created_at REAL NOT NULL,
    dismissed INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS metrics_history(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ts REAL NOT NULL,
    cpu_percent REAL,
    memory_percent REAL,
    disk_percent REAL,
    net_sent INTEGER,
    net_recv INTEGER
);
CREATE TABLE IF NOT EXISTS clipboard_history(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    text TEXT NOT NULL,
    created_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS phone_commands(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    device_id TEXT,
    type TEXT NOT NULL,
    payload TEXT,
    created_at REAL NOT NULL,
    acked INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_metrics_ts ON metrics_history(ts);
CREATE INDEX IF NOT EXISTS idx_commands_acked ON phone_commands(acked);
"""


def hash_value(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()


class Database:
    """Thread-safe thin wrapper around sqlite3."""

    def __init__(self, path: Path = DB_PATH):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(self.path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA busy_timeout=5000")
        self._lock = threading.RLock()
        self.init()

    def init(self) -> None:
        with self._lock:
            self.conn.executescript(SCHEMA)
            self.conn.commit()
        self._migrate()

    def _migrate(self) -> None:
        """Upgrade databases created by older releases (IF NOT EXISTS never alters)."""
        with self._lock:
            cols = {
                row["name"]
                for row in self.conn.execute("PRAGMA table_info(devices)").fetchall()
            }
            if "battery_level" not in cols:
                self.conn.execute("ALTER TABLE devices ADD COLUMN battery_level INTEGER")
            if "battery_status" not in cols:
                self.conn.execute("ALTER TABLE devices ADD COLUMN battery_status TEXT")
            if "last_battery_update" not in cols:
                self.conn.execute(
                    "ALTER TABLE devices ADD COLUMN last_battery_update REAL"
                )
            self.conn.commit()

    # ------------------------------------------------------------- generic --
    def _execute(self, sql: str, params: tuple = ()) -> sqlite3.Cursor:
        with self._lock:
            cur = self.conn.execute(sql, params)
            self.conn.commit()
            return cur

    def _query(self, sql: str, params: tuple = ()) -> list[dict[str, Any]]:
        with self._lock:
            return [dict(row) for row in self.conn.execute(sql, params).fetchall()]

    def log(self, event: str, detail: str = "") -> None:
        self._execute(
            "INSERT INTO logs(event,detail,created_at) VALUES(?,?,?)",
            (event, detail, time.time()),
        )

    # ------------------------------------------------------------ pairing ---
    def create_pairing(self, device_name: str, ttl: int) -> tuple[str, str]:
        code = f"{secrets.randbelow(1000000):06d}"
        rid = secrets.token_urlsafe(12)
        now = time.time()
        self._execute(
            "INSERT INTO pairing_requests(id,code_hash,created_at,expires_at,"
            "approved,device_name) VALUES(?,?,?,?,?,?)",
            (rid, hash_value(code), now, now + ttl, 0, device_name),
        )
        self.log("pairing_created", device_name)
        return rid, code

    def pending_pairings(self) -> list[dict[str, Any]]:
        self._execute("DELETE FROM pairing_requests WHERE expires_at<?", (time.time(),))
        return self._query(
            "SELECT id,device_name,created_at,expires_at FROM pairing_requests "
            "WHERE approved=0 ORDER BY created_at DESC"
        )

    def approve_pairing(self, rid: str) -> dict[str, Any] | None:
        with self._lock:
            row = self.conn.execute(
                "SELECT * FROM pairing_requests WHERE id=? AND approved=0", (rid,)
            ).fetchone()
            if not row or row["expires_at"] < time.time():
                return None
            self.conn.execute(
                "UPDATE pairing_requests SET approved=1 WHERE id=?", (rid,)
            )
            self.conn.commit()
        self.log("pairing_approved", row["device_name"])
        return dict(row)

    def verify_code(self, code: str) -> dict[str, Any] | None:
        row = self._query(
            "SELECT * FROM pairing_requests WHERE code_hash=?", (hash_value(code),)
        )
        if row and row[0]["expires_at"] >= time.time():
            return row[0]
        return None

    def consume_pairing(self, rid: str) -> None:
        self._execute("DELETE FROM pairing_requests WHERE id=?", (rid,))

    # ------------------------------------------------------------ devices ---
    def add_device(self, name: str, token: str) -> str:
        did = secrets.token_urlsafe(12)
        now = time.time()
        self._execute(
            "INSERT INTO devices(id,name,token_hash,created_at,last_seen,revoked,"
            "battery_level,battery_status,last_battery_update) "
            "VALUES(?,?,?,?,?,0,NULL,NULL,NULL)",
            (did, name, hash_value(token), now, now),
        )
        self.log("device_added", name)
        return did

    def device_by_token(self, token: str) -> dict[str, Any] | None:
        rows = self._query(
            "SELECT * FROM devices WHERE token_hash=? AND revoked=0",
            (hash_value(token),),
        )
        if not rows:
            return None
        self._execute(
            "UPDATE devices SET last_seen=? WHERE id=?", (time.time(), rows[0]["id"])
        )
        return rows[0]

    def devices(self) -> list[dict[str, Any]]:
        return self._query("SELECT * FROM devices ORDER BY created_at DESC")

    def device(self, device_id: str) -> dict[str, Any] | None:
        rows = self._query("SELECT * FROM devices WHERE id=?", (device_id,))
        return rows[0] if rows else None

    def revoke_device(self, device_id: str) -> None:
        self._execute("UPDATE devices SET revoked=1 WHERE id=?", (device_id,))
        self.log("device_revoked", device_id)

    def rename_device(self, device_id: str, name: str) -> None:
        self._execute("UPDATE devices SET name=? WHERE id=?", (name, device_id))
        self.log("device_renamed", f"{device_id} -> {name}")

    def update_battery(
        self, device_id: str, level: int | None, status: str | None
    ) -> None:
        self._execute(
            "UPDATE devices SET battery_level=?,battery_status=?,last_battery_update=? "
            "WHERE id=?",
            (level, status, time.time(), device_id),
        )

    # ---------------------------------------------------------- transfers ---
    def transfer(self, name: str, size: int, direction: str, status: str) -> None:
        self._execute(
            "INSERT INTO transfers(filename,size,direction,created_at,status) "
            "VALUES(?,?,?,?,?)",
            (name, size, direction, time.time(), status),
        )

    def transfers(self, limit: int = 100) -> list[dict[str, Any]]:
        return self._query(
            "SELECT * FROM transfers ORDER BY created_at DESC LIMIT ?", (limit,)
        )

    def logs(self, limit: int = 200) -> list[dict[str, Any]]:
        return self._query("SELECT * FROM logs ORDER BY created_at DESC LIMIT ?", (limit,))

    # ----------------------------------------------------- notifications ---
    def add_notification(self, source: str, title: str, text: str) -> int:
        with self._lock:
            cur = self.conn.execute(
                "INSERT INTO notifications(source,title,text,created_at) VALUES(?,?,?,?)",
                (source, title, text, time.time()),
            )
            self.conn.commit()
            nid = cur.lastrowid
        self.log("notification_received", source)
        # Keep the table bounded.
        self._execute(
            "DELETE FROM notifications WHERE id NOT IN "
            "(SELECT id FROM notifications ORDER BY created_at DESC LIMIT ?)",
            (NOTIFICATION_RETENTION,),
        )
        return int(nid)

    def notifications(self, limit: int = 100) -> list[dict[str, Any]]:
        return self._query(
            "SELECT * FROM notifications WHERE dismissed=0 "
            "ORDER BY created_at DESC LIMIT ?",
            (limit,),
        )

    def dismiss_notification(self, nid: int) -> None:
        self._execute("UPDATE notifications SET dismissed=1 WHERE id=?", (nid,))

    # ------------------------------------------------- metrics / clipboard --
    def add_metric_sample(
        self,
        ts: float,
        cpu: float,
        mem: float,
        disk: float,
        net_sent: int,
        net_recv: int,
    ) -> None:
        self._execute(
            "INSERT INTO metrics_history(ts,cpu_percent,memory_percent,disk_percent,"
            "net_sent,net_recv) VALUES(?,?,?,?,?,?)",
            (ts, cpu, mem, disk, net_sent, net_recv),
        )

    def prune_metrics_history(self) -> None:
        cutoff = time.time() - METRICS_HISTORY_RETENTION_HOURS * 3600
        self._execute("DELETE FROM metrics_history WHERE ts<?", (cutoff,))

    def metrics_history(self, limit: int = 2880) -> list[dict[str, Any]]:
        return self._query(
            "SELECT * FROM metrics_history ORDER BY ts DESC LIMIT ?", (limit,)
        )[::-1]

    def add_clipboard(self, text: str) -> None:
        self._execute(
            "INSERT INTO clipboard_history(text,created_at) VALUES(?,?)",
            (text, time.time()),
        )
        self._execute(
            "DELETE FROM clipboard_history WHERE id NOT IN "
            "(SELECT id FROM clipboard_history ORDER BY created_at DESC LIMIT ?)",
            (CLIPBOARD_HISTORY_SIZE,),
        )

    def clipboard_history(self, limit: int = CLIPBOARD_HISTORY_SIZE) -> list[dict[str, Any]]:
        return self._query(
            "SELECT * FROM clipboard_history ORDER BY created_at DESC LIMIT ?", (limit,)
        )

    # ----------------------------------------------------- phone commands ---
    def add_command(self, cmd_type: str, payload: str = "", device_id: str | None = None) -> int:
        with self._lock:
            cur = self.conn.execute(
                "INSERT INTO phone_commands(device_id,type,payload,created_at) "
                "VALUES(?,?,?,?)",
                (device_id, cmd_type, payload, time.time()),
            )
            self.conn.commit()
            return int(cur.lastrowid)

    def pending_commands(self, device_id: str | None = None) -> list[dict[str, Any]]:
        if device_id:
            return self._query(
                "SELECT * FROM phone_commands WHERE acked=0 AND (device_id=? OR "
                "device_id IS NULL) ORDER BY created_at ASC",
                (device_id,),
            )
        return self._query(
            "SELECT * FROM phone_commands WHERE acked=0 ORDER BY created_at ASC"
        )

    def ack_command(self, cid: int) -> None:
        self._execute("UPDATE phone_commands SET acked=1 WHERE id=?", (cid,))

    def cleanup(self) -> None:
        self.prune_metrics_history()
        self._execute("DELETE FROM logs WHERE created_at<?", (time.time() - 30 * 86400,))
        self._execute(
            "DELETE FROM phone_commands WHERE acked=1 AND created_at<?",
            (time.time() - 7 * 86400,),
        )
