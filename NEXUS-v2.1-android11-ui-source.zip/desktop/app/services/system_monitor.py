"""Host system metrics via psutil."""

from __future__ import annotations

import platform
import shutil
import time

import psutil


def metrics() -> dict:
    vm = psutil.virtual_memory()
    du = shutil.disk_usage("/")
    net = psutil.net_io_counters()
    return {
        "cpu_percent": psutil.cpu_percent(interval=0.05),
        "memory_percent": vm.percent,
        "memory_used_bytes": vm.used,
        "memory_total_bytes": vm.total,
        "disk_percent": round(du.used / du.total * 100, 1),
        "disk_used_bytes": du.used,
        "disk_total_bytes": du.total,
        "network_bytes_sent": net.bytes_sent,
        "network_bytes_recv": net.bytes_recv,
        "uptime_seconds": int(time.time() - psutil.boot_time()),
        "platform": platform.platform(),
    }
