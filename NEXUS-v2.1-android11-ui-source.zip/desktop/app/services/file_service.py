"""Filesystem access restricted to the shared directory."""

from __future__ import annotations

import re
from pathlib import Path

from ..config import CHUNK_DIR, MAX_FILE_BYTES, SHARED_DIR

_SEGMENT = re.compile(r"^[A-Za-z0-9._ -]{1,120}$")


def safe_path(name: str, folder: str | None = None) -> Path:
    """Resolve *name* (optionally inside one sub-folder) inside SHARED_DIR."""
    original = Path(name)
    if original.name != name or original.is_absolute() or "/" in name or "\\" in name:
        raise ValueError("Unsafe path")
    if not name or name in {".", ".."} or not _SEGMENT.match(name):
        raise ValueError("Invalid filename")

    base = SHARED_DIR.resolve()
    target = base
    if folder:
        if not _SEGMENT.match(folder) or folder in {".", ".."}:
            raise ValueError("Invalid folder")
        target = (SHARED_DIR / folder).resolve()
        if target.parent != base:
            raise ValueError("Unsafe folder")
        target.mkdir(exist_ok=True)

    p = (target / name).resolve()
    if p.parent != target:
        raise ValueError("Unsafe path")
    return p


def safe_upload_id(upload_id: str) -> Path:
    if not re.match(r"^[A-Za-z0-9_-]{8,64}$", upload_id):
        raise ValueError("Invalid upload id")
    d = (CHUNK_DIR / upload_id).resolve()
    if d.parent != CHUNK_DIR.resolve():
        raise ValueError("Unsafe upload id")
    d.mkdir(exist_ok=True)
    return d


def list_files() -> list[dict]:
    items: list[dict] = []
    for p in sorted(SHARED_DIR.rglob("*")):
        if p.is_file() and p.suffix != ".part":
            rel = p.relative_to(SHARED_DIR)
            items.append(
                {
                    "name": p.name,
                    "folder": str(rel.parent) if str(rel.parent) != "." else "",
                    "size": p.stat().st_size,
                    "modified": p.stat().st_mtime,
                }
            )
    return items


def check_size(size: int) -> None:
    if size > MAX_FILE_BYTES:
        raise ValueError("File exceeds size limit")
