"""Optional mDNS/LAN advertisement of the NEXUS Core (Zeroconf)."""

from __future__ import annotations

import socket
import threading

try:
    from zeroconf import ServiceInfo, Zeroconf
except ImportError:  # pragma: no cover
    Zeroconf = None  # type: ignore[assignment]


class Discovery:
    def __init__(self, port: int = 8765):
        self.port = port
        self.zc = None
        self.info = None
        self.thread: threading.Thread | None = None
        self.error: str | None = None

    def _register(self) -> None:
        try:
            host = socket.gethostname()
            ip = socket.gethostbyname(host)
            self.info = ServiceInfo(
                "_nexus._tcp.local.",
                f"NEXUS Core ({host})._nexus._tcp.local.",
                addresses=[socket.inet_aton(ip)],
                port=self.port,
                properties={b"version": b"2.0", b"mode": b"lan"},
            )
            zc = Zeroconf()
            zc.register_service(self.info)
            self.zc = zc
        except Exception as exc:  # pragma: no cover - environment dependent
            self.error = str(exc)
            self.zc = None

    def start(self) -> bool:
        if not Zeroconf:
            return False
        self.thread = threading.Thread(
            target=self._register, name="nexus-mdns", daemon=True
        )
        self.thread.start()
        return True

    def stop(self) -> None:
        try:
            if self.zc and self.info:
                self.zc.unregister_service(self.info)
                self.zc.close()
        except Exception:  # pragma: no cover
            pass
        self.zc = None
