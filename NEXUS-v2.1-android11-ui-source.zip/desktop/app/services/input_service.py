"""Remote keyboard/mouse control via xdotool (allowlisted actions only)."""

from __future__ import annotations

import shutil
import subprocess


class InputService:
    """Thin wrapper around xdotool. Never executes arbitrary shell strings."""

    @staticmethod
    def available() -> bool:
        return shutil.which("xdotool") is not None

    @staticmethod
    def _run(args: list[str]) -> bool:
        if not shutil.which("xdotool"):
            return False
        try:
            result = subprocess.run(
                args, timeout=5, capture_output=True, text=True, check=False
            )
            return result.returncode == 0
        except Exception:
            return False

    @classmethod
    def key(cls, key: str) -> bool:
        return cls._run(["xdotool", "key", "--clearmodifiers", key])

    @classmethod
    def type_text(cls, text: str) -> bool:
        # "--" prevents text starting with a dash from being parsed as a flag.
        return cls._run(["xdotool", "type", "--clearmodifiers", "--delay", "12", "--", text])

    @classmethod
    def mouse(cls, action: str, dx: int, dy: int) -> bool:
        if action == "move":
            return cls._run(["xdotool", "mousemove_relative", "--", str(dx), str(dy)])
        if action == "click":
            return cls._run(["xdotool", "click", "1"])
        if action == "right":
            return cls._run(["xdotool", "click", "3"])
        if action == "double":
            return cls._run(["xdotool", "click", "--repeat", "2", "--delay", "120", "1"])
        if action == "scroll":
            button = "5" if dy >= 0 else "4"
            return cls._run(["xdotool", "click", button])
        return False
