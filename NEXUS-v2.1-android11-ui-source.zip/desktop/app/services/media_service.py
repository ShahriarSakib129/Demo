"""Media control via playerctl and volume via pactl/amixer."""

from __future__ import annotations

import re
import shutil
import subprocess


def _run(args: list[str], timeout: int = 4) -> subprocess.CompletedProcess | None:
    if not shutil.which(args[0]):
        return None
    try:
        return subprocess.run(args, timeout=timeout, capture_output=True, text=True)
    except Exception:
        return None


class MediaService:
    ACTIONS = {"play", "pause", "play-pause", "next", "previous", "stop"}

    @staticmethod
    def available() -> bool:
        return shutil.which("playerctl") is not None

    @staticmethod
    def status() -> dict:
        if not MediaService.available():
            return {"available": False, "message": "Install playerctl to enable media controls"}
        state = _run(["playerctl", "status"])
        title = _run(["playerctl", "metadata", "xesam:title"])
        artist = _run(["playerctl", "metadata", "xesam:artist"])
        return {
            "available": True,
            "state": (state.stdout.strip() if state else "unknown"),
            "title": (title.stdout.strip() if title else ""),
            "artist": (artist.stdout.strip() if artist else ""),
        }

    @staticmethod
    def control(action: str) -> bool:
        if action not in MediaService.ACTIONS:
            return False
        result = _run(["playerctl", action])
        return result is not None and result.returncode == 0

    @staticmethod
    def set_volume(level: int) -> bool:
        level = max(0, min(100, level))
        if shutil.which("pactl"):
            result = _run(["pactl", "set-sink-volume", "@DEFAULT_SINK@", f"{level}%"])
            return result is not None and result.returncode == 0
        if shutil.which("amixer"):
            result = _run(["amixer", "-q", "set", "Master", f"{level}%"])
            return result is not None and result.returncode == 0
        return False
