"""Background sampler that records host metrics into SQLite."""

from __future__ import annotations

import threading
import time

from .system_monitor import metrics


class MetricsSampler:
    def __init__(self, db, interval: int = 30):
        self.db = db
        self.interval = interval
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def _loop(self) -> None:
        samples = 0
        while not self._stop.wait(self.interval):
            try:
                m = metrics()
                self.db.add_metric_sample(
                    time.time(),
                    m["cpu_percent"],
                    m["memory_percent"],
                    m["disk_percent"],
                    m["network_bytes_sent"],
                    m["network_bytes_recv"],
                )
                samples += 1
                if samples % 120 == 0:
                    self.db.cleanup()
            except Exception:
                pass

    def start(self) -> None:
        self._thread = threading.Thread(
            target=self._loop, name="nexus-metrics-sampler", daemon=True
        )
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
