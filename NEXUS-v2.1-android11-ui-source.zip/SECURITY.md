# Security policy

Report vulnerabilities privately to the project owner. Do not include secrets in issue reports.

## Supported versions

| Version | Supported |
|---|---|
| 2.0.x | ✅ |
| 1.0.x | critical fixes only |

## Threat model

- v2.0 is designed for a **trusted LAN or private overlay network** (Tailscale/WireGuard).
- Do **not** expose port 8765 to the public internet.
- The admin token (`~/.nexus-data/admin_token`) grants pairing control — keep it private.
- Notification mirroring and SMS relay are sensitive: enable only when you trust the PC and network.
- For production-grade transport, terminate HTTPS on a trusted reverse proxy or overlay.

## Security features

- Pairing codes: 6-digit, 5-minute TTL, SHA-256 hashed, desktop approval required
- Admin token: constant-time comparison, 0600 permissions, env override
- Device tokens: 256-bit random, SHA-256 hashed at rest, revocable per device
- Rate limiting: 240 req/min per IP
- File API: traversal-safe, size-capped, atomic writes
- No arbitrary shell execution; power/input/media use allowlisted commands only
