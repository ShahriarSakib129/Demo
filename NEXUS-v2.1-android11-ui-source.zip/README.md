# NEXUS v2.0

**Private, local-first bridge between Android and Linux.** Your phone becomes a remote control for your PC — files, clipboard, notifications, media, keyboard/mouse, find-my-phone — without any cloud.

## Features (v2.0)

| Area | What you get |
|---|---|
| 🔐 **Pairing** | 6-digit code + desktop approval, QR pairing, admin-token protected, 5-min expiry |
| 📊 **Dashboard** | CPU/RAM/disk/network/uptime live metrics + 48h history charts |
| 📁 **Files** | Upload/download/delete, drag & drop, resumable chunked upload, photo backup, organize automation |
| 📋 **Clipboard** | Phone ↔ PC clipboard sync + history |
| 🔔 **Notifications** | Mirror phone notifications to PC, dismiss/open on phone remotely |
| ⌨️ **Remote input** | Keyboard typing, hotkeys, virtual touchpad (mouse move/click/scroll) |
| 🎵 **Media** | Play/pause/next/previous, volume control (playerctl/pactl) |
| ⚡ **Power** | Lock/suspend/restart/shutdown with explicit confirmation |
| 📱 **Phone side** | Battery status on PC, **find my phone** (ring + vibrate), SMS relay, share-to-PC |
| 🌐 **Realtime** | WebSocket events + polling fallback, LAN discovery (mDNS/Zeroconf) |
| 🛡️ **Security** | Bearer tokens (hashed server-side), Keystore-backed storage on Android, rate limiting, path-traversal-safe file API, no arbitrary shell execution |

## Architecture

```text
Android (Kotlin/Compose) ──HTTP + Bearer──▶ FastAPI Core ──▶ SQLite / psutil / shared dir
Desktop GUI (PySide6) ──admin token──────▶ FastAPI Core
                         └── WebSocket ◀── realtime events
```

## Linux quick start

```bash
python3 -m venv .venv
. .venv/bin/activate
pip install -r desktop/requirements.txt
python -m pytest desktop/tests -q          # 17 tests
python -m desktop.app.main --core          # API on :8765
python -m desktop.app.main --gui           # desktop console
python -m desktop.app.main --show-admin-token
```

The admin token is auto-generated at `~/.nexus-data/admin_token` (or set `NEXUS_ADMIN_TOKEN`). Pairing endpoints require it — the GUI reads it automatically.

## Pair Android

1. Start the Core and open the desktop GUI → **Pairing** tab.
2. Press **Create pairing code** (QR shows the payload).
3. On the phone: enter the PC address + code (or **Scan QR**).
4. Double-click the pending request in the GUI to approve.
5. Done — the token is stored in Android Keystore-backed encrypted preferences.

For LAN use, enter the PC's LAN IP (`http://192.168.x.x:8765`). For remote use, use a Tailscale/WireGuard address and never port-forward 8765.

## Android build

```bash
cd android
./gradlew assembleDebug        # APK in app/build/outputs/apk/debug/
./gradlew assembleRelease      # sign with your keystore
```

Open `android/` in Android Studio (Hedgehog+) for development. Minimum SDK 26, target SDK 35.

## Optional Linux tools

| Tool | Unlocks |
|---|---|
| `xclip` or `xsel` | clipboard sync |
| `xdotool` | remote keyboard/mouse |
| `playerctl` + `pactl` | media & volume control |
| `zeroconf` (pip) | LAN discovery |

## Configuration

| Env var | Default | Purpose |
|---|---|---|
| `NEXUS_BIND` | `0.0.0.0` | listen address |
| `NEXUS_PORT` | `8765` | listen port |
| `NEXUS_DATA_DIR` | `~/.nexus-data` | DB, tokens, chunks |
| `NEXUS_SHARED_DIR` | `$DATA_DIR/shared` | file exchange folder |
| `NEXUS_ADMIN_TOKEN` | auto-generated | pairing admin token |
| `NEXUS_MAX_FILE_BYTES` | 200 MB | upload cap |

## Security notes

- Pairing codes expire in 5 minutes; tokens are stored as SHA-256 hashes on Linux.
- `/pairing/*` endpoints require the admin token; everything else a device bearer token.
- File paths are confined to `NEXUS_SHARED_DIR` (traversal-safe, one-level folders).
- Dangerous power/automation actions require explicit confirmation.
- LAN transport is for a trusted network; use Tailscale/WireGuard for remote access.

See `docs/` for the [protocol](docs/protocol.md), [architecture](docs/architecture.md), [roadmap](ROADMAP.md) and setup guides. Report issues privately per [SECURITY.md](SECURITY.md).


## NEXUS v2.0 review notes

- The desktop Core now defaults to `127.0.0.1` for safer first-run behavior. For LAN access, explicitly configure `NEXUS_BIND` after reviewing `docs/remote-access.md` and firewall rules.
- Android and Linux GUI colors have been aligned to an Obsidian Black / Graphite / Electric Purple theme.
- The supplied debug APK has **not** been rebuilt from these source changes in this environment. Build and test the Android project in Android Studio before installing a newly compiled APK.
- Review `SECURITY.md` and remote access documentation before exposing the service to other devices.
