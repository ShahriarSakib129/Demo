package com.nexus.app

import android.content.Intent
import android.net.Uri
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

private data class RemoteFile(val name:String,val size:Long)
private data class RemoteNotification(val id:Int,val source:String,val title:String,val text:String)

class MainActivity:ComponentActivity(){
 private val client=OkHttpClient.Builder().connectTimeout(8,TimeUnit.SECONDS).readTimeout(30,TimeUnit.SECONDS).build()
 private val prefs by lazy{EncryptedSharedPreferences.create("nexus_secure",MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC),this,EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)}
 override fun onCreate(state:Bundle?){super.onCreate(state);setContent{NexusApp()}}
 @Composable private fun NexusApp(){
  var base by remember{mutableStateOf(prefs.getString("base","http://192.168.1.10:8765")?:"")};var code by remember{mutableStateOf("")};var name by remember{mutableStateOf("My Android")};var status by remember{mutableStateOf("Not connected")};var dashboard by remember{mutableStateOf("Pair a device to load metrics")};var files by remember{mutableStateOf(emptyList<RemoteFile>())};var notices by remember{mutableStateOf(emptyList<RemoteNotification>())};var clip by remember{mutableStateOf("")};var clipInput by remember{mutableStateOf("")};var busy by remember{mutableStateOf(false)};var notificationEnabled by remember{mutableStateOf(getSharedPreferences("nexus_notification",MODE_PRIVATE).getBoolean("enabled",false))};var confirmAction by remember{mutableStateOf<String?>(null)}
  val picker=rememberLauncherForActivityResult(ActivityResultContracts.GetContent()){u->if(u!=null){busy=true;upload(base,u,nameOf(u)){status=it;busy=false}}}
  MaterialTheme{Scaffold{padding->LazyColumn(Modifier.padding(padding).padding(18.dp),verticalArrangement=Arrangement.spacedBy(9.dp)){
   item{Text("NEXUS",style=MaterialTheme.typography.headlineLarge);Text("Private Android × Linux ecosystem");OutlinedTextField(base,{base=it},label={Text("Linux Core URL / Tailscale IP")},modifier=Modifier.fillMaxWidth());OutlinedTextField(name,{name=it},label={Text("Device name")},modifier=Modifier.fillMaxWidth());OutlinedTextField(code,{code=it.filter(Char::isDigit).take(6)},label={Text("6-digit pairing code")},modifier=Modifier.fillMaxWidth())
    Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){Button(enabled=!busy,onClick={busy=true;pair(base,code,name){status=it;busy=false}}){Text("Pair")};OutlinedButton(enabled=!busy,onClick={busy=true;metrics(base){dashboard=it;busy=false}}){Text("Refresh")};TextButton(onClick={discover{if(it.isNotEmpty())base=it;status=if(it.isEmpty())"No Core found" else "Discovered $it"}}){Text("Discover")}}
    Text(status);Card(Modifier.fillMaxWidth()){Text(dashboard,Modifier.padding(12.dp))}
    Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){Button(enabled=!busy,onClick={busy=true;listFiles(base){files=it;busy=false}}){Text("List files")};OutlinedButton(enabled=!busy,onClick={picker.launch("*/*")}){Text("Upload")}}
    Text("Files",style=MaterialTheme.typography.titleMedium)
    HorizontalDivider();Text("Clipboard",style=MaterialTheme.typography.titleMedium);OutlinedTextField(clipInput,{clipInput=it},label={Text("Text to send to Linux")},modifier=Modifier.fillMaxWidth());Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){Button(onClick={setClipboard(base,clipInput){status=it}}){Text("Send")};OutlinedButton(onClick={getClipboard(base){clip=it}}){Text("Read")}};if(clip.isNotEmpty())Text("Linux clipboard: $clip")
    HorizontalDivider();Text("Notifications",style=MaterialTheme.typography.titleMedium);Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){Switch(checked=notificationEnabled,onCheckedChange={notificationEnabled=it;getSharedPreferences("nexus_notification",MODE_PRIVATE).edit().putBoolean("enabled",it).apply()});Text("Mirror notifications")};Button(onClick={startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))}){Text("Open notification permission")};OutlinedButton(onClick={loadNotifications(base){notices=it}}){Text("Refresh notifications")}
    HorizontalDivider();Text("Safe PC controls",style=MaterialTheme.typography.titleMedium);Text("No arbitrary terminal or sudo execution is provided.",style=MaterialTheme.typography.bodySmall);Row(horizontalArrangement=Arrangement.spacedBy(5.dp)){Button(onClick={confirmAction="suspend"}){Text("Suspend")};OutlinedButton(onClick={confirmAction="restart"}){Text("Restart")};OutlinedButton(onClick={confirmAction="shutdown"}){Text("Shutdown")}}
    HorizontalDivider();Text("Automation",style=MaterialTheme.typography.titleMedium);OutlinedButton(onClick={organize(base){status=it}}){Text("Organize shared files")}
   }
   items(files){f->Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("${f.name} • ${f.size} bytes",Modifier.weight(1f));TextButton(onClick={download(base,f.name){status=it}}){Text("Download")}}}
   items(notices){n->Card(Modifier.fillMaxWidth()){Column(Modifier.padding(10.dp)){Text(n.title,style=MaterialTheme.typography.titleSmall);Text("${n.source}: ${n.text}");TextButton(onClick={dismiss(base,n.id){status=it}}){Text("Dismiss")}}}}
  }};confirmAction?.let{action->AlertDialog(onDismissRequest={confirmAction=null},title={Text("Confirm $action")},text={Text("This will $action the Linux PC. Continue?")},confirmButton={TextButton(onClick={confirmAction=null;power(base,action){status=it}}){Text("Confirm")}},dismissButton={TextButton(onClick={confirmAction=null}){Text("Cancel")}})}}}
 private fun auth(base:String,path:String):Request.Builder?{val t=prefs.getString("token",null)?:return null;return Request.Builder().url(base.trimEnd('/')+path).header("Authorization","Bearer $t")}
 private fun pair(base:String,code:String,name:String,cb:(String)->Unit)=bg{try{val b=JSONObject(mapOf("code" to code,"device_name" to name)).toString().toRequestBody("application/json".toMediaType());val r=client.newCall(Request.Builder().url(base.trimEnd('/')+"/pair").post(b).build()).execute();val s=r.body?.string().orEmpty();cb(if(r.isSuccessful){prefs.edit().putString("base",base).putString("token",JSONObject(s).getString("token")).apply();"Paired successfully"}else"Pairing failed (${r.code})")}catch(e:Exception){cb("Connection error: ${e.message}")}}
 private fun metrics(base:String,cb:(String)->Unit)=bg{try{val r=auth(base,"/metrics")?:return@bg cb("No pairing token");val x=client.newCall(r.get().build()).execute();val j=JSONObject(x.body?.string().orEmpty());cb(if(x.isSuccessful)"CPU ${j.getDouble("cpu_percent")}%, RAM ${j.getDouble("memory_percent")}%, Disk ${j.getDouble("disk_percent")}%, Uptime ${j.getLong("uptime_seconds")}s" else "Metrics failed (${x.code})")}catch(e:Exception){cb("Connection error: ${e.message}")}}
 private fun listFiles(base:String,cb:(List<RemoteFile>)->Unit)=bg{try{val r=auth(base,"/files")?:return@bg cb(emptyList());val a=JSONObject(client.newCall(r.get().build()).execute().body?.string().orEmpty()).getJSONArray("items");cb((0 until a.length()).map{val o=a.getJSONObject(it);RemoteFile(o.getString("name"),o.getLong("size"))})}catch(_:Exception){cb(emptyList())}}
 private fun upload(base:String,u:Uri,n:String,cb:(String)->Unit)=bg{try{val f=File(cacheDir,"upload_${System.currentTimeMillis()}");contentResolver.openInputStream(u)?.use{i->f.outputStream().use{o->i.copyTo(o)}};val r=auth(base,"/files/upload")?:return@bg cb("No pairing token");val p=MultipartBody.Part.createFormData("file",n,f.asRequestBody("application/octet-stream".toMediaType()));val x=client.newCall(r.post(MultipartBody.Builder().setType(MultipartBody.FORM).addPart(p).build()).build()).execute();f.delete();cb(if(x.isSuccessful)"Uploaded $n" else"Upload failed (${x.code})")}catch(e:Exception){cb("Upload error: ${e.message}")}}
 private fun download(base:String,n:String,cb:(String)->Unit)=bg{try{val r=auth(base,"/files/${Uri.encode(n)}")?:return@bg cb("No pairing token");val x=client.newCall(r.get().build()).execute();if(!x.isSuccessful)return@bg cb("Download failed (${x.code})");val o=File(getExternalFilesDir(null),n);x.body?.byteStream()?.use{i->o.outputStream().use{q->i.copyTo(q)}};cb("Downloaded ${o.name}")}catch(e:Exception){cb("Download error: ${e.message}")}}
 private fun setClipboard(base:String,t:String,cb:(String)->Unit)=bg{try{val r=auth(base,"/clipboard")?:return@bg cb("No pairing token");val x=client.newCall(r.post(JSONObject(mapOf("text" to t)).toString().toRequestBody("application/json".toMediaType())).build()).execute();cb(if(x.isSuccessful)"Clipboard updated" else"Clipboard failed (${x.code})")}catch(e:Exception){cb("Clipboard error: ${e.message}")}}
 private fun getClipboard(base:String,cb:(String)->Unit)=bg{try{val r=auth(base,"/clipboard")?:return@bg cb("No pairing token");val x=client.newCall(r.get().build()).execute();cb(JSONObject(x.body?.string().orEmpty()).optString("text","Clipboard unavailable"))}catch(e:Exception){cb("Clipboard error: ${e.message}")}}
 private fun power(base:String,a:String,cb:(String)->Unit)=bg{try{val r=auth(base,"/power/$a")?:return@bg cb("No pairing token");val x=client.newCall(r.post("{\"confirm\":true}".toRequestBody("application/json".toMediaType())).build()).execute();cb(if(x.isSuccessful)"$a request accepted" else"$a failed (${x.code})")}catch(e:Exception){cb("Power error: ${e.message}")}}
 private fun organize(base:String,cb:(String)->Unit)=bg{try{val r=auth(base,"/automations/run")?:return@bg cb("No pairing token");val x=client.newCall(r.post("{\"action\":\"organize_shared\",\"confirm\":true}".toRequestBody("application/json".toMediaType())).build()).execute();cb(if(x.isSuccessful)"Shared files organized" else"Automation failed (${x.code})")}catch(e:Exception){cb("Automation error: ${e.message}")}}
 private fun loadNotifications(base:String,cb:(List<RemoteNotification>)->Unit)=bg{try{val r=auth(base,"/notifications")?:return@bg cb(emptyList());val a=JSONObject(client.newCall(r.get().build()).execute().body?.string().orEmpty()).getJSONArray("items");cb((0 until a.length()).map{val o=a.getJSONObject(it);RemoteNotification(o.getInt("id"),o.getString("source"),o.getString("title"),o.optString("text"))})}catch(_:Exception){cb(emptyList())}}
 private fun dismiss(base:String,id:Int,cb:(String)->Unit)=bg{try{val r=auth(base,"/notifications/$id/dismiss")?:return@bg cb("No pairing token");val x=client.newCall(r.post("".toRequestBody()).build()).execute();cb(if(x.isSuccessful)"Dismissed" else"Dismiss failed")}catch(e:Exception){cb("Dismiss error: ${e.message}")}}
 private fun discover(cb:(String)->Unit){val nsd=getSystemService(NSD_SERVICE) as NsdManager;var done=false;lateinit var l:NsdManager.DiscoveryListener;fun finish(v:String){if(!done){done=true;nsd.stopServiceDiscovery(l);cb(v)}};l=object:NsdManager.DiscoveryListener{override fun onDiscoveryStarted(s:String){};override fun onServiceFound(i:NsdServiceInfo){if(i.serviceType.contains("_nexus"))nsd.resolveService(i,object:NsdManager.ResolveListener{override fun onResolveFailed(x:NsdServiceInfo,e:Int){};override fun onServiceResolved(x:NsdServiceInfo){finish("http://${x.host.hostAddress}:${x.port}")}})};override fun onServiceLost(i:NsdServiceInfo){};override fun onDiscoveryStopped(s:String){if(!done)cb("")};override fun onStartDiscoveryFailed(s:String,e:Int){finish("")};override fun onStopDiscoveryFailed(s:String,e:Int){done=true;cb("")}};nsd.discoverServices("_nexus._tcp",NsdManager.PROTOCOL_DNS_SD,l);android.os.Handler(mainLooper).postDelayed({finish("")},5000)}
 private fun nameOf(u:Uri)=u.lastPathSegment?.substringAfterLast('/')?.takeIf{it.isNotBlank()}?:"android-file"
 private fun bg(block:()->Unit){GlobalScope.launch(Dispatchers.IO){block()}}
}
