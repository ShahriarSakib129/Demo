# Protocol v0.2

- `GET /health` public liveness check
- `POST /pairing/create` desktop creates a short-lived code
- `GET /pairing/pending` desktop lists requests
- `POST /pairing/approve` desktop approves request id
- `POST /pair` Android exchanges approved code for bearer token
- Authenticated: `GET /metrics`, `GET /devices`, `GET /files`, `POST /files/upload`, `GET /files/{name}`
- Authenticated: `GET /transfers`, `GET /logs`, `POST /devices/{id}/revoke`, `GET/POST /clipboard`, `POST /power/{action}`, `GET /automations`, `POST /automations/run`

LAN discovery advertises `_nexus._tcp.local.` when Zeroconf is installed. Remote access is manual-address only through a private Tailscale/WireGuard network; public port forwarding is not supported.

Send `Authorization: Bearer <token>`.
