# Android setup

Open `android/` in Android Studio. Set the PC base URL in the app to the Linux machine LAN IP, not `localhost`. The app requires Android SDK 35 and internet access once to resolve Gradle dependencies.
