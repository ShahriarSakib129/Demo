# Architecture

Android talks to the authenticated FastAPI Core over HTTP. The Core owns SQLite, metrics and the approved shared directory. The PySide6 GUI is an operator console for pairing and health. WebSocket events and advanced controls are planned after v0.1.

```text
Android -> FastAPI Core -> SQLite / system metrics / shared files
Linux GUI -> FastAPI Core
```
