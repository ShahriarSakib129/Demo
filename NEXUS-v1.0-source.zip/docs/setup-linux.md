# Linux Mint setup

Install Python 3.12 and create a virtual environment; do not use sudo pip:

```bash
cd NEXUS
python3 -m venv .venv
. .venv/bin/activate
pip install -r desktop/requirements.txt
python -m pytest desktop/tests -q
python -m desktop.app.main --core
```

In another terminal run `python -m desktop.app.main --gui`.
