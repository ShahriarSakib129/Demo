# Security policy

Report vulnerabilities privately to the project owner. Do not include secrets in issue reports. v0.1 is an MVP and should be used on a trusted LAN or private overlay network only.
