# NEXUS v1.0

Private, local-first bridge between Android and Linux.

## v0.1 scope
- FastAPI NEXUS Core service
- Short-lived pairing code with explicit approval
- Bearer-token authentication and device revocation
- CPU, RAM, disk, network and uptime metrics
- Safe file upload/download inside an approved folder
- PySide6 desktop dashboard
- Android Kotlin/Compose client foundation with pairing/dashboard screens
- Android notification-access permission screen and LAN Zeroconf discovery
- SQLite persistence, logs, tests and systemd example
- Opt-in Android notification forwarding, clipboard controls and LAN discovery
- Allowlisted power actions and confirmed file-organize automation

> This release is an MVP. LAN transport is intended for a trusted network; for remote use, place it behind Tailscale/WireGuard and do not port-forward the API.

## Linux quick start
```bash
python3 -m venv .venv
. .venv/bin/activate
pip install -r desktop/requirements.txt
python -m pytest desktop/tests -q
python -m desktop.app.main --core
# in another terminal
python -m desktop.app.main --gui
```

Core listens on `0.0.0.0:8765` by default. Set `NEXUS_BIND`, `NEXUS_PORT`, and `NEXUS_DATA_DIR` to override. The desktop GUI connects to `http://127.0.0.1:8765` by default.

## Pair Android
1. Start the Core.
2. Open the desktop GUI and press **Create pairing code**.
3. In Android, enter the PC address and code.
4. Approve the request in the desktop GUI using the pending pairing panel.
5. The Android app stores the token in Android Keystore-backed encrypted preferences.

For LAN use, replace `127.0.0.1` with the Linux PC's LAN IP. Do not expose port 8765 directly to the internet.

## Android
Open `android/` in Android Studio Hedgehog or newer. The v0.1 app includes manual Core URL entry, pairing-code submission, Android Keystore-backed token storage, authenticated CPU/RAM/disk/uptime dashboard, shared-folder file listing, and file upload through the system picker. A local Android SDK/Gradle setup is required; this repository does not claim an Android build was run in environments without the SDK.

For a LAN test, enter the Linux PC LAN address, for example `http://192.168.1.20:8765`; do not use `localhost` on the phone. The manifest permits cleartext HTTP for trusted-LAN MVP testing. For remote use, use a Tailscale/WireGuard address and prefer HTTPS/private-network transport.

## Security notes
- Pairing codes expire after 5 minutes and are rate-limited.
- Tokens are stored as hashes on Linux; Android uses encrypted preferences backed by Android Keystore.
- File paths are constrained to the configured `NEXUS_SHARED_DIR`.
- No arbitrary shell execution exists.
- Dangerous power controls are intentionally deferred from v0.1.
- For production TLS, terminate HTTPS on a private overlay network or trusted reverse proxy.

See `docs/` for architecture, protocol, Linux, Android, remote access and troubleshooting.
See `docs/phase3-phase4.md` for notification permissions, LAN discovery and private remote-network setup.
