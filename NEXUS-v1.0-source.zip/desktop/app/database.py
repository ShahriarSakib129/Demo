import sqlite3, secrets, hashlib, time
from pathlib import Path
from .config import DB_PATH

class Database:
    def __init__(self, path: Path = DB_PATH):
        self.path=path; self.path.parent.mkdir(parents=True,exist_ok=True)
        self.conn=sqlite3.connect(self.path,check_same_thread=False); self.conn.row_factory=sqlite3.Row; self.init()
    def init(self):
        self.conn.executescript('''
        CREATE TABLE IF NOT EXISTS devices(id TEXT PRIMARY KEY,name TEXT NOT NULL,token_hash TEXT NOT NULL,created_at REAL NOT NULL,last_seen REAL,revoked INTEGER NOT NULL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS pairing_requests(id TEXT PRIMARY KEY,code_hash TEXT NOT NULL,created_at REAL NOT NULL,expires_at REAL NOT NULL,approved INTEGER NOT NULL DEFAULT 0,device_name TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS transfers(id INTEGER PRIMARY KEY AUTOINCREMENT,filename TEXT NOT NULL,size INTEGER NOT NULL,direction TEXT NOT NULL,created_at REAL NOT NULL,status TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS logs(id INTEGER PRIMARY KEY AUTOINCREMENT,event TEXT NOT NULL,detail TEXT,created_at REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS notifications(id INTEGER PRIMARY KEY AUTOINCREMENT,source TEXT NOT NULL,title TEXT NOT NULL,text TEXT,created_at REAL NOT NULL,dismissed INTEGER NOT NULL DEFAULT 0);
        '''); self.conn.commit()
    @staticmethod
    def h(value): return hashlib.sha256(value.encode()).hexdigest()
    def log(self,event,detail=''): self.conn.execute('INSERT INTO logs(event,detail,created_at) VALUES(?,?,?)',(event,detail,time.time())); self.conn.commit()
    def create_pairing(self,device_name,ttl):
        code=f'{secrets.randbelow(1000000):06d}'; rid=secrets.token_urlsafe(12); now=time.time(); self.conn.execute('INSERT INTO pairing_requests VALUES(?,?,?,?,?,?)',(rid,self.h(code),now,now+ttl,0,device_name)); self.conn.commit(); self.log('pairing_created',device_name); return rid,code
    def pending(self):
        self.conn.execute('DELETE FROM pairing_requests WHERE expires_at<?',(time.time(),)); self.conn.commit(); return [dict(x) for x in self.conn.execute('SELECT id,device_name,created_at,expires_at FROM pairing_requests WHERE approved=0 ORDER BY created_at DESC')]
    def approve(self,rid):
        row=self.conn.execute('SELECT * FROM pairing_requests WHERE id=? AND approved=0',(rid,)).fetchone()
        if not row or row['expires_at']<time.time(): return None
        self.conn.execute('UPDATE pairing_requests SET approved=1 WHERE id=?',(rid,)); self.conn.commit(); self.log('pairing_approved',row['device_name']); return dict(row)
    def verify_code(self,code):
        row=self.conn.execute('SELECT * FROM pairing_requests WHERE code_hash=?',(self.h(code),)).fetchone(); return row if row and row['expires_at']>=time.time() else None
    def consume_pairing(self,rid): self.conn.execute('DELETE FROM pairing_requests WHERE id=?',(rid,)); self.conn.commit()
    def add_device(self,name,token):
        did=secrets.token_urlsafe(12); self.conn.execute('INSERT INTO devices VALUES(?,?,?,?,?,0)',(did,name,self.h(token),time.time(),time.time())); self.conn.commit(); self.log('device_added',name); return did
    def device_by_token(self,token):
        row=self.conn.execute('SELECT * FROM devices WHERE token_hash=? AND revoked=0',(self.h(token),)).fetchone()
        if row: self.conn.execute('UPDATE devices SET last_seen=? WHERE id=?',(time.time(),row['id'])); self.conn.commit()
        return row
    def devices(self): return [dict(x) for x in self.conn.execute('SELECT id,name,created_at,last_seen,revoked FROM devices ORDER BY created_at DESC')]
    def revoke(self,did): self.conn.execute('UPDATE devices SET revoked=1 WHERE id=?',(did,)); self.conn.commit(); self.log('device_revoked',did)
    def transfer(self,name,size,direction,status): self.conn.execute('INSERT INTO transfers(filename,size,direction,created_at,status) VALUES(?,?,?,?,?)',(name,size,direction,time.time(),status)); self.conn.commit()
    def transfers(self): return [dict(x) for x in self.conn.execute('SELECT * FROM transfers ORDER BY created_at DESC LIMIT 100')]
    def logs(self): return [dict(x) for x in self.conn.execute('SELECT * FROM logs ORDER BY created_at DESC LIMIT 200')]
    def add_notification(self,source,title,text): self.conn.execute('INSERT INTO notifications(source,title,text,created_at) VALUES(?,?,?,?)',(source,title,text,time.time())); self.conn.commit(); self.log('notification_received',source)
    def notifications(self): return [dict(x) for x in self.conn.execute('SELECT * FROM notifications WHERE dismissed=0 ORDER BY created_at DESC LIMIT 100')]
    def dismiss_notification(self,nid): self.conn.execute('UPDATE notifications SET dismissed=1 WHERE id=?',(nid,)); self.conn.commit()
