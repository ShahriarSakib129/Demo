import socket
import threading

try:
    from zeroconf import Zeroconf, ServiceInfo
except ImportError:
    Zeroconf = None

class Discovery:
    def __init__(self, port=8765):
        self.port=port; self.zc=None; self.info=None; self.thread=None; self.error=None
    def _register(self):
        try:
            host=socket.gethostname(); ip=socket.gethostbyname(host)
            self.info=ServiceInfo('_nexus._tcp.local.', f'NEXUS Core ({host})._nexus._tcp.local.', addresses=[socket.inet_aton(ip)], port=self.port, properties={b'version':b'0.3', b'mode':b'lan'})
            zc=Zeroconf(); zc.register_service(self.info)
            self.zc=zc
        except Exception as exc:
            self.error=str(exc); self.zc=None
    def start(self):
        if not Zeroconf: return False
        self.thread=threading.Thread(target=self._register, name='nexus-mdns', daemon=True); self.thread.start(); return True
    def stop(self):
        try:
            if self.zc and self.info:
                self.zc.unregister_service(self.info); self.zc.close()
        except Exception:
            pass
        self.zc=None
