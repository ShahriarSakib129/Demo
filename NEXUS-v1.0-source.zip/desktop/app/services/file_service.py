from pathlib import Path
from ..config import SHARED_DIR, MAX_FILE_BYTES

def safe_path(name):
    original=Path(name)
    if original.name != name or original.is_absolute(): raise ValueError('Unsafe path')
    name=original.name
    if not name or name in {'.','..'}: raise ValueError('Invalid filename')
    p=(SHARED_DIR/name).resolve()
    if p.parent!=SHARED_DIR.resolve(): raise ValueError('Unsafe path')
    return p

def list_files(): return [{'name':p.name,'size':p.stat().st_size} for p in SHARED_DIR.iterdir() if p.is_file()]
