import argparse, uvicorn
from .config import BIND,PORT

def main():
 p=argparse.ArgumentParser(); p.add_argument('--core',action='store_true'); p.add_argument('--gui',action='store_true'); p.add_argument('--host',default=BIND); p.add_argument('--port',type=int,default=PORT); a=p.parse_args()
 if a.gui:
  from .gui.main_window import run; raise SystemExit(run())
 uvicorn.run('desktop.app.server:app',host=a.host,port=a.port,reload=False)
if __name__=='__main__': main()
