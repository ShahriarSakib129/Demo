import secrets, time, subprocess, shutil
from collections import defaultdict, deque
from fastapi import FastAPI, Header, HTTPException, UploadFile, File, Request
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from .database import Database
from .config import PAIRING_TTL, MAX_FILE_BYTES, SHARED_DIR
from .services.system_monitor import metrics
from .services.file_service import safe_path, list_files
from .services.discovery import Discovery

db=Database(); app=FastAPI(title='NEXUS Core', version='1.0.0')
discovery=Discovery()
_hits=defaultdict(deque)
class PairRequest(BaseModel): code:str=Field(min_length=6,max_length=6); device_name:str=Field(min_length=1,max_length=80)
class ApproveRequest(BaseModel): request_id:str
class TextPayload(BaseModel): text:str=Field(max_length=10000)
class PowerPayload(BaseModel): confirm:bool=False
class AutomationPayload(BaseModel): action:str; confirm:bool=False
class NotificationPayload(BaseModel): source:str=Field(min_length=1,max_length=160); title:str=Field(max_length=300); text:str=Field(default='',max_length=2000)

def auth(authorization):
    if not authorization or not authorization.startswith('Bearer '): raise HTTPException(401,'Authentication required')
    row=db.device_by_token(authorization[7:])
    if not row: raise HTTPException(401,'Invalid or revoked token')
    return row
@app.middleware('http')
async def rate_limit(request:Request, call_next):
    if request.url.path not in ('/health','/pairing/pending'):
        q=_hits[request.client.host if request.client else 'unknown']; now=time.time()
        while q and q[0]<now-60: q.popleft()
        if len(q)>=120: raise HTTPException(429,'Too many requests; retry later')
        q.append(now)
    return await call_next(request)
@app.on_event('startup')
def discovery_start(): discovery.start()
@app.on_event('shutdown')
def discovery_stop(): discovery.stop()
@app.get('/health')
def health(): return {'status':'ok','version':'1.0.0','discovery':'enabled' if discovery.zc else 'unavailable','remote_mode':'private-overlay-ready'}
@app.post('/pairing/create')
def create_pairing(device_name:str='Android device'):
    rid,code=db.create_pairing(device_name,PAIRING_TTL); return {'request_id':rid,'code':code,'expires_in':PAIRING_TTL}
@app.get('/pairing/pending')
def pending(): return {'items':db.pending()}
@app.post('/pairing/approve')
def approve(req:ApproveRequest):
    if not db.approve(req.request_id): raise HTTPException(404,'Pairing request expired or not found')
    return {'approved':True}
@app.post('/pair')
def pair(req:PairRequest):
    row=db.verify_code(req.code)
    if not row: raise HTTPException(401,'Invalid or expired pairing code')
    if not row['approved']: raise HTTPException(403,'Pairing requires desktop approval')
    token=secrets.token_urlsafe(32); did=db.add_device(req.device_name,token); db.consume_pairing(row['id']); return {'device_id':did,'token':token,'name':req.device_name}
@app.get('/metrics')
def get_metrics(authorization:str|None=Header(default=None)): auth(authorization); return metrics()
@app.get('/devices')
def devices(authorization:str|None=Header(default=None)): auth(authorization); return {'items':db.devices()}
@app.post('/devices/{device_id}/revoke')
def revoke(device_id:str, authorization:str|None=Header(default=None)):
    auth(authorization); db.revoke(device_id); return {'revoked':True}
@app.get('/logs')
def logs(authorization:str|None=Header(default=None)): auth(authorization); return {'items':db.logs()}
@app.get('/transfers')
def transfers(authorization:str|None=Header(default=None)): auth(authorization); return {'items':db.transfers()}
@app.get('/notifications')
def notifications(authorization:str|None=Header(default=None)): auth(authorization); return {'items':db.notifications()}
@app.post('/notifications')
def receive_notification(payload:NotificationPayload, authorization:str|None=Header(default=None)):
    auth(authorization); db.add_notification(payload.source,payload.title,payload.text); return {'received':True}
@app.post('/notifications/{notification_id}/dismiss')
def dismiss_notification(notification_id:int, authorization:str|None=Header(default=None)):
    auth(authorization); db.dismiss_notification(notification_id); return {'dismissed':True}
@app.get('/files')
def files(authorization:str|None=Header(default=None)): auth(authorization); return {'items':list_files()}
@app.post('/files/upload')
async def upload(file:UploadFile=File(...), authorization:str|None=Header(default=None)):
    auth(authorization); p=safe_path(file.filename or 'unnamed'); total=0; tmp=p.with_suffix(p.suffix+'.part')
    try:
        with tmp.open('wb') as out:
            while chunk:=await file.read(1024*1024):
                total+=len(chunk)
                if total>MAX_FILE_BYTES: raise HTTPException(413,'File exceeds size limit')
                out.write(chunk)
        tmp.replace(p); db.transfer(p.name,total,'upload','complete'); return {'name':p.name,'size':total}
    except HTTPException: tmp.unlink(missing_ok=True); raise
    except Exception: tmp.unlink(missing_ok=True); raise HTTPException(500,'Upload failed')
@app.get('/files/{name}')
def download(name:str, authorization:str|None=Header(default=None)):
    auth(authorization); p=safe_path(name)
    if not p.exists(): raise HTTPException(404,'File not found')
    db.transfer(p.name,p.stat().st_size,'download','complete'); return FileResponse(p,filename=p.name)

# Explicit clipboard controls. Platform tools may be unavailable; report that honestly.
@app.get('/clipboard')
def clipboard_get(authorization:str|None=Header(default=None)):
    auth(authorization)
    if shutil.which('xclip'):
        return {'available':True,'text':subprocess.check_output(['xclip','-selection','clipboard','-o'],text=True,timeout=2)}
    if shutil.which('xsel'):
        return {'available':True,'text':subprocess.check_output(['xsel','--clipboard','--output'],text=True,timeout=2)}
    return {'available':False,'text':'','message':'Install xclip or xsel to enable clipboard controls'}
@app.post('/clipboard')
def clipboard_set(payload:TextPayload, authorization:str|None=Header(default=None)):
    auth(authorization)
    cmd=['xclip','-selection','clipboard'] if shutil.which('xclip') else (['xsel','--clipboard','--input'] if shutil.which('xsel') else None)
    if not cmd: raise HTTPException(503,'Install xclip or xsel to enable clipboard controls')
    subprocess.run(cmd,input=payload.text,text=True,timeout=2,check=True); db.log('clipboard_set','text_length='+str(len(payload.text))); return {'updated':True}

@app.post('/power/{action}')
def power(action:str, payload:PowerPayload, authorization:str|None=Header(default=None)):
    auth(authorization)
    commands={'suspend':['systemctl','suspend'],'restart':['systemctl','reboot'],'shutdown':['systemctl','poweroff']}
    if action != 'lock' and action not in commands: raise HTTPException(400,'Unsupported power action')
    if not payload.confirm: raise HTTPException(400,'Explicit confirmation required')
    db.log('power_requested',action)
    try:
        if action == 'lock':
            session = __import__('os').environ.get('XDG_SESSION_ID')
            attempts=[]
            if session: attempts.append(['loginctl','--no-ask-password','lock-session',session])
            attempts += [['xdg-screensaver','lock'], ['gnome-screensaver-command','--lock'], ['dm-tool','lock']]
            for command in attempts:
                if shutil.which(command[0]):
                    result=subprocess.run(command, timeout=5, capture_output=True, text=True)
                    if result.returncode == 0: return {'accepted':True,'action':action}
            raise RuntimeError('No desktop lock command succeeded; try installing xdg-utils or run from the graphical user session')
        subprocess.Popen(commands[action], start_new_session=True)
    except Exception as e: raise HTTPException(500,f'Power action failed: {e}')
    return {'accepted':True,'action':action}

@app.get('/automations')
def automations(authorization:str|None=Header(default=None)):
    auth(authorization); return {'items':[{'id':'organize_shared','label':'Organize shared files by extension','dangerous':False}]}
@app.post('/automations/run')
def run_automation(payload:AutomationPayload, authorization:str|None=Header(default=None)):
    auth(authorization)
    if payload.action!='organize_shared': raise HTTPException(400,'Unknown or disallowed automation')
    if not payload.confirm: raise HTTPException(400,'Explicit confirmation required')
    moved=0
    for p in list(SHARED_DIR.iterdir()):
        if p.is_file() and not p.name.endswith('.part'):
            folder=SHARED_DIR/(p.suffix[1:].lower() or 'other'); folder.mkdir(exist_ok=True); p.rename(folder/p.name); moved+=1
    db.log('automation_run',f'organize_shared moved={moved}'); return {'action':payload.action,'moved':moved}
