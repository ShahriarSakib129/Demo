import sys, requests
from PySide6.QtWidgets import QApplication,QMainWindow,QVBoxLayout,QWidget,QLabel,QPushButton,QListWidget,QMessageBox,QLineEdit,QHBoxLayout
class MainWindow(QMainWindow):
 def __init__(self,base='http://127.0.0.1:8765'):
  super().__init__(); self.base=base; self.setWindowTitle('NEXUS v0.1'); self.resize(600,500)
  self.status=QLabel('Disconnected'); self.metrics=QLabel('No metrics yet'); self.code=QLabel('No active pairing code'); self.pending=QListWidget()
  self.code_btn=QPushButton('Create pairing code'); self.refresh_btn=QPushButton('Refresh metrics'); self.pending_btn=QPushButton('Refresh pending pairings')
  box=QVBoxLayout(); box.addWidget(QLabel('<h1>NEXUS</h1><p>Private Android × Linux ecosystem</p>')); box.addWidget(self.status); box.addWidget(self.metrics); box.addWidget(self.code); box.addWidget(self.code_btn); box.addWidget(QLabel('Pending pairings (double-click to approve):')); box.addWidget(self.pending); box.addWidget(self.pending_btn); box.addWidget(self.refresh_btn)
  w=QWidget(); w.setLayout(box); self.setCentralWidget(w); self.code_btn.clicked.connect(self.create_code); self.pending_btn.clicked.connect(self.load_pending); self.refresh_btn.clicked.connect(self.load_metrics); self.pending.itemDoubleClicked.connect(self.approve)
  self.load_metrics(); self.load_pending()
 def create_code(self):
  try:
   r=requests.post(self.base+'/pairing/create',params={'device_name':'Android device'},timeout=3); r.raise_for_status(); j=r.json(); self.code.setText(f"Pairing code: {j['code']} (expires in {j['expires_in']}s)"); self.load_pending()
  except Exception as e: QMessageBox.warning(self,'NEXUS',str(e))
 def load_pending(self):
  self.pending.clear()
  try:
   for x in requests.get(self.base+'/pairing/pending',timeout=3).json()['items']: self.pending.addItem(f"{x['id']} | {x['device_name']}")
  except Exception: pass
 def approve(self,item):
  rid=item.text().split(' | ')[0]
  try: requests.post(self.base+'/pairing/approve',json={'request_id':rid},timeout=3).raise_for_status(); self.load_pending(); QMessageBox.information(self,'NEXUS','Pairing approved. The Android app may now submit the code.')
  except Exception as e: QMessageBox.warning(self,'NEXUS',str(e))
 def load_metrics(self):
  try:
   j=requests.get(self.base+'/health',timeout=3).json(); self.status.setText('Core: connected')
   self.metrics.setText('Core is healthy. Pair a device to view authenticated metrics.')
  except Exception as e: self.status.setText('Core: unavailable'); self.metrics.setText(str(e))
def run(): app=QApplication(sys.argv); win=MainWindow(); win.show(); return app.exec()
