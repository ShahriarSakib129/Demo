import os
from pathlib import Path

DATA_DIR=Path(os.getenv("NEXUS_DATA_DIR", Path.home()/".nexus-data"))
DATA_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH=DATA_DIR/"nexus.sqlite3"
SHARED_DIR=Path(os.getenv("NEXUS_SHARED_DIR", DATA_DIR/"shared"))
SHARED_DIR.mkdir(parents=True, exist_ok=True)
BIND=os.getenv("NEXUS_BIND", "0.0.0.0")
PORT=int(os.getenv("NEXUS_PORT", "8765"))
PAIRING_TTL=300
MAX_FILE_BYTES=100*1024*1024
