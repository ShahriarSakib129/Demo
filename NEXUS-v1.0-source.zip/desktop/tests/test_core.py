from fastapi.testclient import TestClient
from desktop.app import server
from desktop.app.services.file_service import safe_path

def client_token():
    c=TestClient(server.app); item=c.post('/pairing/create',params={'device_name':'test'}).json(); c.post('/pairing/approve',json={'request_id':item['request_id']}); r=c.post('/pair',json={'code':item['code'],'device_name':'phone'}); return c,{'Authorization':'Bearer '+r.json()['token']}

def test_health():
    assert TestClient(server.app).get('/health').json()['status']=='ok'

def test_pair_requires_approval():
    c=TestClient(server.app); item=c.post('/pairing/create',params={'device_name':'test'}).json(); assert c.post('/pair',json={'code':item['code'],'device_name':'phone'}).status_code==403

def test_pair_after_approval_and_auth():
    c,h=client_token(); assert c.get('/metrics',headers=h).status_code==200; assert c.get('/metrics').status_code==401

def test_safe_file_path():
    assert safe_path('abc.txt').name=='abc.txt'
    try: safe_path('../secret')
    except ValueError: pass
    else: assert False

def test_notification_roundtrip():
    c,h=client_token(); assert c.post('/notifications',headers=h,json={'source':'test.app','title':'Hello','text':'World'}).status_code==200
    items=c.get('/notifications',headers=h).json()['items']; assert any(x['title']=='Hello' for x in items)
    assert c.get('/logs',headers=h).status_code==200

def test_power_requires_explicit_confirmation():
    c,h=client_token(); assert c.post('/power/restart',headers=h,json={'confirm':False}).status_code==400
